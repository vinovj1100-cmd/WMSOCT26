import { auth } from "@/lib/auth";
import { headers } from "next/headers";
import { redirect } from "next/navigation";
import { db } from "@/lib/db";
import { user, userRole } from "@/lib/db/schema";
import { eq } from "drizzle-orm";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { AlertsPanel } from "@/components/alerts-panel";
import { Users, Shield, User as UserIcon } from "lucide-react";

export const metadata = {
  title: "User Management - G-SHEET WMS",
};

export default async function UserManagementPage() {
  const session = await auth.api.getSession({ headers: await headers() });
  if (!session?.user) redirect("/sign-in");

  const userRoleData = await db
    .select()
    .from(userRole)
    .where(eq(userRole.userId, session.user.id));
  const role = userRoleData[0]?.role || "staff";

  if (role !== "admin") {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold mb-2">Access Denied</h1>
          <p className="text-muted-foreground mb-4">
            Only admins can manage users
          </p>
          <Link href="/">
            <Button>Back to Dashboard</Button>
          </Link>
        </div>
      </div>
    );
  }

  const users = await db.query.user.findMany({
    with: {
      role: true,
    },
  });

  const admins = users.filter((u) => u.role?.role === "admin");
  const staff = users.filter((u) => u.role?.role === "staff");

  return (
    <div className="min-h-screen bg-background">
      <header className="bg-primary text-primary-foreground shadow-md">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Users className="w-6 h-6" />
              <div>
                <h1 className="text-2xl font-bold">User Management</h1>
                <p className="text-sm opacity-90">
                  Manage warehouse staff and admin access
                </p>
              </div>
            </div>
            <div className="flex items-center gap-4">
              <AlertsPanel />
              <Link href="/">
                <Button variant="secondary" size="sm">
                  Dashboard
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-8">
          <div className="bg-white rounded-lg border border-border p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-muted-foreground text-sm">Total Users</p>
                <p className="text-3xl font-bold mt-1">{users.length}</p>
              </div>
              <Users className="w-8 h-8 text-primary opacity-20" />
            </div>
          </div>

          <div className="bg-white rounded-lg border border-border p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-muted-foreground text-sm">Active Sessions</p>
                <p className="text-3xl font-bold mt-1">{users.length}</p>
              </div>
              <UserIcon className="w-8 h-8 text-blue-500 opacity-20" />
            </div>
          </div>
        </div>

        {/* Administrators */}
        <div className="bg-white border border-border rounded-lg overflow-hidden mb-8">
          <div className="p-6 border-b border-border bg-blue-50">
            <h2 className="text-xl font-bold flex items-center gap-2">
              <Shield className="w-5 h-5" />
              Administrators ({admins.length})
            </h2>
          </div>
          {admins.length === 0 ? (
            <div className="p-6 text-center text-muted-foreground">
              No administrators
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-border bg-gray-50">
                    <th className="text-left py-3 px-4 text-sm font-semibold">
                      Name
                    </th>
                    <th className="text-left py-3 px-4 text-sm font-semibold">
                      Email
                    </th>
                    <th className="text-left py-3 px-4 text-sm font-semibold">
                      Role
                    </th>
                    <th className="text-left py-3 px-4 text-sm font-semibold">
                      Joined
                    </th>
                    <th className="text-left py-3 px-4 text-sm font-semibold">
                      Actions
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {admins.map((u) => (
                    <tr key={u.id} className="border-b border-border hover:bg-gray-50">
                      <td className="py-3 px-4 font-medium">{u.name}</td>
                      <td className="py-3 px-4 text-sm">{u.email}</td>
                      <td className="py-3 px-4">
                        <span className="px-2 py-1 rounded text-xs font-medium bg-blue-100 text-blue-800">
                          Admin
                        </span>
                      </td>
                      <td className="py-3 px-4 text-sm">
                        {new Date(u.createdAt).toLocaleDateString()}
                      </td>
                      <td className="py-3 px-4 text-sm">
                        <Button size="sm" variant="outline">
                          Edit
                        </Button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>

        {/* Staff */}
        <div className="bg-white border border-border rounded-lg overflow-hidden">
          <div className="p-6 border-b border-border bg-green-50">
            <h2 className="text-xl font-bold flex items-center gap-2">
              <UserIcon className="w-5 h-5" />
              Staff Members ({staff.length})
            </h2>
          </div>
          {staff.length === 0 ? (
            <div className="p-6 text-center text-muted-foreground">
              No staff members
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-border bg-gray-50">
                    <th className="text-left py-3 px-4 text-sm font-semibold">
                      Name
                    </th>
                    <th className="text-left py-3 px-4 text-sm font-semibold">
                      Email
                    </th>
                    <th className="text-left py-3 px-4 text-sm font-semibold">
                      Role
                    </th>
                    <th className="text-left py-3 px-4 text-sm font-semibold">
                      Joined
                    </th>
                    <th className="text-left py-3 px-4 text-sm font-semibold">
                      Actions
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {staff.map((u) => (
                    <tr key={u.id} className="border-b border-border hover:bg-gray-50">
                      <td className="py-3 px-4 font-medium">{u.name}</td>
                      <td className="py-3 px-4 text-sm">{u.email}</td>
                      <td className="py-3 px-4">
                        <span className="px-2 py-1 rounded text-xs font-medium bg-green-100 text-green-800">
                          Staff
                        </span>
                      </td>
                      <td className="py-3 px-4 text-sm">
                        {new Date(u.createdAt).toLocaleDateString()}
                      </td>
                      <td className="py-3 px-4 text-sm">
                        <Button size="sm" variant="outline">
                          Edit
                        </Button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </main>
    </div>
  );
}
