"use server";

import { auth } from "@/lib/auth";
import { db } from "@/lib/db";
import {
  orders,
  orderItems,
  inventory,
  inventoryMovements,
  alerts,
  userRole,
} from "@/lib/db/schema";
import { eq, desc, and, gte } from "drizzle-orm";
import { headers } from "next/headers";
import { revalidatePath } from "next/cache";

async function getUserId() {
  const session = await auth.api.getSession({ headers: await headers() });
  if (!session?.user) throw new Error("Unauthorized");
  return session.user.id;
}

async function getUserRole(userId: string) {
  const roleData = await db
    .select()
    .from(userRole)
    .where(eq(userRole.userId, userId));
  return roleData[0]?.role || "staff";
}

export async function getOrders() {
  const userId = await getUserId();
  const role = await getUserRole(userId);

  if (role === "admin") {
    return db.query.orders.findMany({
      orderBy: [desc(orders.createdAt)],
      with: {
        items: true,
        assignedUser: {
          columns: {
            name: true,
            email: true,
          },
        },
      },
    });
  } else {
    return db.query.orders.findMany({
      where: eq(orders.assignedTo, userId),
      orderBy: [desc(orders.createdAt)],
      with: {
        items: true,
        assignedUser: {
          columns: {
            name: true,
            email: true,
          },
        },
      },
    });
  }
}

export async function getOrderById(orderId: string) {
  const userId = await getUserId();
  const role = await getUserRole(userId);

  const where =
    role === "admin"
      ? eq(orders.id, orderId)
      : and(eq(orders.id, orderId), eq(orders.assignedTo, userId));

  return db.query.orders.findFirst({
    where,
    with: {
      items: true,
      assignedUser: {
        columns: {
          name: true,
          email: true,
        },
      },
    },
  });
}

export async function updateOrderStatus(orderId: string, newStatus: string) {
  const userId = await getUserId();
  const role = await getUserRole(userId);

  if (role !== "admin" && role !== "staff")
    throw new Error("Unauthorized action");

  const currentOrder = await db
    .select()
    .from(orders)
    .where(eq(orders.id, orderId));

  if (!currentOrder[0]) throw new Error("Order not found");

  const statusMap: Record<string, string> = {
    received: "received",
    picked: "picked",
    packed: "packed",
    shipped: "shipped",
  };

  if (!statusMap[newStatus]) throw new Error("Invalid status");

  const updateData: any = {
    status: newStatus,
    updatedAt: new Date(),
  };

  if (newStatus === "received") updateData.receivedAt = new Date();
  if (newStatus === "picked") updateData.pickedAt = new Date();
  if (newStatus === "packed") updateData.packedAt = new Date();
  if (newStatus === "shipped") updateData.shippedAt = new Date();

  await db.update(orders).set(updateData).where(eq(orders.id, orderId));

  revalidatePath("/");
}

export async function assignOrder(orderId: string, staffUserId: string) {
  const userId = await getUserId();
  const role = await getUserRole(userId);

  if (role !== "admin") throw new Error("Only admins can assign orders");

  await db
    .update(orders)
    .set({ assignedTo: staffUserId, updatedAt: new Date() })
    .where(eq(orders.id, orderId));

  revalidatePath("/");
}

export async function addOrderNote(orderId: string, note: string) {
  const userId = await getUserId();
  const currentOrder = await db
    .select()
    .from(orders)
    .where(eq(orders.id, orderId));

  if (!currentOrder[0]) throw new Error("Order not found");

  const existingNotes = currentOrder[0].notes || "";
  const timestamp = new Date().toLocaleString();
  const newNote = `[${timestamp}] ${note}`;
  const updatedNotes = existingNotes
    ? `${existingNotes}\n${newNote}`
    : newNote;

  await db
    .update(orders)
    .set({ notes: updatedNotes, updatedAt: new Date() })
    .where(eq(orders.id, orderId));

  revalidatePath("/");
}
