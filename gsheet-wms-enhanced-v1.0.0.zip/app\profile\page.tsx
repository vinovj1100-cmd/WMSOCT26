import { auth } from "@/lib/auth";
import { headers } from "next/headers";
import { redirect } from "next/navigation";
import { db } from "@/lib/db";
import { userRole } from "@/lib/db/schema";
import { eq } from "drizzle-orm";
import { Button } from "@/components/ui/button";
import Link from "next/link";
import { AlertsPanel } from "@/components/alerts-panel";
import { LogOut, Mail, User } from "lucide-react";

export const metadata = {
  title: "Profile - G-SHEET WMS",
};

export default async function ProfilePage() {
  const session = await auth.api.getSession({ headers: await headers() });
  if (!session?.user) redirect("/sign-in");

  const userRoleData = await db
    .select()
    .from(userRole)
    .where(eq(userRole.userId, session.user.id));
  const role = userRoleData[0]?.role || "staff";

  return (
    <div className="min-h-screen bg-background">
      <header className="bg-primary text-primary-foreground shadow-md">
        <div className="max-w-2xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold">User Profile</h1>
            </div>
            <div className="flex items-center gap-4">
              <AlertsPanel />
              <Link href="/">
                <Button variant="secondary" size="sm">
                  Dashboard
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-2xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="bg-white border border-border rounded-lg p-8">
          <div className="space-y-6">
            {/* Profile Header */}
            <div className="flex items-center gap-4 pb-6 border-b border-border">
              <div className="w-16 h-16 rounded-full bg-primary text-primary-foreground flex items-center justify-center text-2xl font-bold">
                {session.user.name?.charAt(0) || session.user.email.charAt(0)}
              </div>
              <div>
                <h2 className="text-2xl font-bold">
                  {session.user.name || "User"}
                </h2>
                <p className="text-muted-foreground">
                  {role === "admin" ? "🔐 Administrator" : "👤 Staff Member"}
                </p>
              </div>
            </div>

            {/* User Information */}
            <div className="space-y-4">
              <h3 className="text-lg font-semibold">Account Information</h3>

              <div className="bg-gray-50 rounded-lg p-4">
                <div className="flex items-center gap-3 mb-2">
                  <Mail className="w-5 h-5 text-muted-foreground" />
                  <div>
                    <p className="text-xs text-muted-foreground">Email Address</p>
                    <p className="font-medium">{session.user.email}</p>
                  </div>
                </div>
              </div>

              <div className="bg-gray-50 rounded-lg p-4">
                <div className="flex items-center gap-3 mb-2">
                  <User className="w-5 h-5 text-muted-foreground" />
                  <div>
                    <p className="text-xs text-muted-foreground">Display Name</p>
                    <p className="font-medium">
                      {session.user.name || "Not set"}
                    </p>
                  </div>
                </div>
              </div>

              <div className="bg-gray-50 rounded-lg p-4">
                <div>
                  <p className="text-xs text-muted-foreground mb-1">Role</p>
                  <span
                    className={`inline-block px-3 py-1 rounded-lg text-sm font-medium ${
                      role === "admin"
                        ? "bg-blue-100 text-blue-800"
                        : "bg-green-100 text-green-800"
                    }`}
                  >
                    {role === "admin" ? "Administrator" : "Staff"}
                  </span>
                </div>
              </div>

              <div className="bg-gray-50 rounded-lg p-4">
                <div>
                  <p className="text-xs text-muted-foreground mb-1">
                    Member Since
                  </p>
                  <p className="font-medium">
                    {new Date(session.user.createdAt || new Date()).toLocaleDateString()}
                  </p>
                </div>
              </div>
            </div>

            {/* Permissions */}
            <div>
              <h3 className="text-lg font-semibold mb-4">Permissions</h3>
              <div className="space-y-2">
                <div className="flex items-center gap-2">
                  <div className="w-5 h-5 rounded bg-green-100 flex items-center justify-center">
                    <span className="text-green-700 text-xs">✓</span>
                  </div>
                  <span>View Dashboard</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-5 h-5 rounded bg-green-100 flex items-center justify-center">
                    <span className="text-green-700 text-xs">✓</span>
                  </div>
                  <span>View Orders</span>
                </div>
                {role === "admin" && (
                  <>
                    <div className="flex items-center gap-2">
                      <div className="w-5 h-5 rounded bg-green-100 flex items-center justify-center">
                        <span className="text-green-700 text-xs">✓</span>
                      </div>
                      <span>Manage Orders</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="w-5 h-5 rounded bg-green-100 flex items-center justify-center">
                        <span className="text-green-700 text-xs">✓</span>
                      </div>
                      <span>Manage Inventory</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="w-5 h-5 rounded bg-green-100 flex items-center justify-center">
                        <span className="text-green-700 text-xs">✓</span>
                      </div>
                      <span>Manage Users</span>
                    </div>
                  </>
                )}
              </div>
            </div>
          </div>

          {/* Logout */}
          <form action="/api/auth/sign-out" method="POST" className="mt-8 pt-8 border-t border-border">
            <Button type="submit" variant="outline" className="w-full flex items-center justify-center gap-2">
              <LogOut className="w-4 h-4" />
              Sign Out
            </Button>
          </form>
        </div>
      </main>
    </div>
  );
}
