import { auth } from "@/lib/auth";
import { headers } from "next/headers";
import { redirect } from "next/navigation";
import { getInventory, getLowStockItems } from "@/app/actions/inventory";
import { db } from "@/lib/db";
import { userRole } from "@/lib/db/schema";
import { eq } from "drizzle-orm";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { AlertsPanel } from "@/components/alerts-panel";
import { Package, AlertTriangle } from "lucide-react";

export const metadata = {
  title: "Inventory - G-SHEET WMS",
  description: "Inventory management",
};

export default async function InventoryPage() {
  const session = await auth.api.getSession({ headers: await headers() });
  if (!session?.user) redirect("/sign-in");

  const userRoleData = await db
    .select()
    .from(userRole)
    .where(eq(userRole.userId, session.user.id));
  const role = userRoleData[0]?.role || "staff";

  if (role !== "admin") {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold mb-2">Access Denied</h1>
          <p className="text-muted-foreground mb-4">
            Only admins can manage inventory
          </p>
          <Link href="/">
            <Button>Back to Dashboard</Button>
          </Link>
        </div>
      </div>
    );
  }

  const [inventory, lowStockItems] = await Promise.all([
    getInventory(),
    getLowStockItems(),
  ]);

  const inStockItems = inventory.filter(
    (item) => item.quantity > item.minimumLevel
  );

  return (
    <div className="min-h-screen bg-background">
      <header className="bg-primary text-primary-foreground shadow-md">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold">Inventory Management</h1>
            </div>
            <div className="flex items-center gap-4">
              <AlertsPanel />
              <Link href="/">
                <Button variant="secondary" size="sm">
                  Dashboard
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
          <div className="bg-white rounded-lg border border-border p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-muted-foreground text-sm">Total SKUs</p>
                <p className="text-3xl font-bold mt-1">{inventory.length}</p>
              </div>
              <Package className="w-8 h-8 text-primary opacity-20" />
            </div>
          </div>

          <div className="bg-white rounded-lg border border-border p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-muted-foreground text-sm">In Stock</p>
                <p className="text-3xl font-bold mt-1 text-green-600">
                  {inStockItems.length}
                </p>
              </div>
              <Package className="w-8 h-8 text-green-500 opacity-20" />
            </div>
          </div>

          <div className="bg-white rounded-lg border border-border p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-muted-foreground text-sm">Low Stock</p>
                <p className="text-3xl font-bold mt-1 text-red-600">
                  {lowStockItems.length}
                </p>
              </div>
              <AlertTriangle className="w-8 h-8 text-red-500 opacity-20" />
            </div>
          </div>
        </div>

        {/* Low Stock Items */}
        {lowStockItems.length > 0 && (
          <div className="bg-red-50 border border-red-200 rounded-lg p-6 mb-8">
            <h2 className="text-xl font-bold text-red-900 mb-4 flex items-center gap-2">
              <AlertTriangle className="w-5 h-5" />
              Low Stock Items ({lowStockItems.length})
            </h2>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-red-200">
                    <th className="text-left py-3 px-4 text-sm font-semibold text-red-900">
                      SKU
                    </th>
                    <th className="text-left py-3 px-4 text-sm font-semibold text-red-900">
                      Product Name
                    </th>
                    <th className="text-left py-3 px-4 text-sm font-semibold text-red-900">
                      Current Stock
                    </th>
                    <th className="text-left py-3 px-4 text-sm font-semibold text-red-900">
                      Minimum Level
                    </th>
                    <th className="text-left py-3 px-4 text-sm font-semibold text-red-900">
                      Location
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {lowStockItems.map((item) => (
                    <tr key={item.id} className="border-b border-red-100">
                      <td className="py-3 px-4 font-mono text-sm text-red-900">
                        {item.skuId}
                      </td>
                      <td className="py-3 px-4 text-sm text-red-900">
                        {item.productName}
                      </td>
                      <td className="py-3 px-4 text-sm font-bold text-red-600">
                        {item.quantity}
                      </td>
                      <td className="py-3 px-4 text-sm text-red-900">
                        {item.minimumLevel}
                      </td>
                      <td className="py-3 px-4 text-sm text-red-900">
                        {item.location || "N/A"}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* All Inventory */}
        <div className="bg-white border border-border rounded-lg overflow-hidden">
          <div className="p-6 border-b border-border">
            <h2 className="text-xl font-bold">All Inventory</h2>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-border bg-gray-50">
                  <th className="text-left py-3 px-4 text-sm font-semibold">SKU</th>
                  <th className="text-left py-3 px-4 text-sm font-semibold">
                    Product Name
                  </th>
                  <th className="text-left py-3 px-4 text-sm font-semibold">
                    Current Stock
                  </th>
                  <th className="text-left py-3 px-4 text-sm font-semibold">
                    Minimum Level
                  </th>
                  <th className="text-left py-3 px-4 text-sm font-semibold">Location</th>
                  <th className="text-left py-3 px-4 text-sm font-semibold">Status</th>
                </tr>
              </thead>
              <tbody>
                {inventory.map((item) => (
                  <tr key={item.id} className="border-b border-border hover:bg-gray-50">
                    <td className="py-3 px-4 font-mono text-sm">{item.skuId}</td>
                    <td className="py-3 px-4 text-sm">{item.productName}</td>
                    <td className="py-3 px-4 text-sm font-semibold">
                      {item.quantity}
                    </td>
                    <td className="py-3 px-4 text-sm">{item.minimumLevel}</td>
                    <td className="py-3 px-4 text-sm">
                      {item.location || "N/A"}
                    </td>
                    <td className="py-3 px-4 text-sm">
                      <span
                        className={`px-2 py-1 rounded text-xs font-medium ${
                          item.quantity > item.minimumLevel
                            ? "bg-green-100 text-green-800"
                            : "bg-red-100 text-red-800"
                        }`}
                      >
                        {item.quantity > item.minimumLevel
                          ? "✓ In Stock"
                          : "⚠ Low Stock"}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </main>
    </div>
  );
}
