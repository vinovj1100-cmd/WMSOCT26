import { auth } from "@/lib/auth";
import { headers } from "next/headers";
import { redirect } from "next/navigation";
import AuthForm from "@/components/auth-form";

export const metadata = {
  title: "Sign Up - G-SHEET WMS",
  description: "Create a new account for the warehouse management system",
};

export default async function SignUpPage() {
  const session = await auth.api.getSession({ headers: await headers() });
  if (session?.user) redirect("/");

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        <div className="bg-white rounded-lg shadow-lg p-8">
          <div className="text-center mb-8">
            <h1 className="text-3xl font-bold text-gray-900">G-SHEET WMS</h1>
            <p className="text-gray-600 mt-2">Create Your Account</p>
          </div>
          <AuthForm mode="sign-up" />
        </div>
      </div>
    </div>
  );
}
