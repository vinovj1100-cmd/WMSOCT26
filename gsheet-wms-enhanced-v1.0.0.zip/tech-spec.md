# Vortex WMS - Technical Specification

## Dependencies

### Core Framework
- `react` ^19.0.0
- `react-dom` ^19.0.0
- `react-router-dom` ^7.0.0
- `typescript` ^5.7.0
- `vite` ^6.0.0

### Styling
- `tailwindcss` ^4.0.0
- `tailwind-merge` ^3.0.0
- `clsx` ^2.1.0
- `class-variance-authority` ^0.7.0

### UI Components (shadcn/ui)
- `@radix-ui/react-dialog`
- `@radix-ui/react-dropdown-menu`
- `@radix-ui/react-select`
- `@radix-ui/react-toast`
- `@radix-ui/react-tooltip`
- `@radix-ui/react-tabs`
- `@radix-ui/react-avatar`
- `@radix-ui/react-switch`
- `@radix-ui/react-separator`
- `@radix-ui/react-scroll-area`
- `@radix-ui/react-popover`
- `@radix-ui/react-alert-dialog`
- `@radix-ui/react-label`
- `lucide-react` ^0.460.0

### 3D / Animation
- `three` ^0.170.0
- `@react-three/fiber` ^9.0.0
- `@react-three/drei` ^10.0.0
- `framer-motion` ^12.0.0

### Data & Utilities
- `dexie` ^4.0.0 (IndexedDB wrapper for offline storage)
- `dexie-react-hooks` ^1.1.0
- `react-countup` ^6.5.0
- `date-fns` ^4.0.0 (date formatting)
- `uuid` ^11.0.0 (generate IDs)

## Component Inventory

### Layout Components
| Component | Source | Reuse |
|-----------|--------|-------|
| AppLayout | Custom | Single - wraps entire authenticated app |
| Sidebar | Custom | Single - fixed 240px glass sidebar |
| TopBar | Custom | Single - glass top bar with operator info |
| HolographicBackground | Custom (design.md) | Single - 3D R3F canvas behind main stage |
| SyncStatus | Custom (design.md) | Single - waveform indicator in top bar |
| AuthLayout | Custom | Single - login page layout |

### Reusable UI Components
| Component | Source | Used By |
|-----------|--------|---------|
| KineticCounter | Custom (design.md) | Dashboard KPI cards |
| BarcodeReader | Custom (design.md) | PickPack, Returns modules |
| GlassPanel | Custom | All modules - wrapper for glass panels |
| DataTable | Custom | Inventory, Orders, Returns - dense data grid |
| StatusBadge | Custom | Multiple - colored status pills |
| ActionButton | Custom | All modules - orange primary buttons |
| Modal | shadcn Dialog | All modules |
| Toast | shadcn Toast | Global notifications |

### Module Pages
| Component | Description |
|-----------|-------------|
| Dashboard | KPI grid, activity feed, quick stats |
| InboundReceiving | SKU scan, qty input, bin assignment |
| InventoryHub | Zone map + master stock table, low stock alerts |
| PickPack | Order selection, scan verification, ship action |
| Returns | Return processing with reason codes |
| PDFSequencer | PDF upload, barcode extraction, page sorting |
| Auditor | Master vs scan discrepancy analysis |
| BulkConverter | Title translation and standardization |
| Settings | Operator config, cloud sync, system settings |
| UserManagement | Admin-only user CRUD |

## Animation Implementation

| Animation | Library | Approach | Complexity |
|-----------|---------|----------|------------|
| 3D Helical Particle Scanner | R3F + Custom Shader | Two counter-rotating BufferGeometry helices with custom vertex/fragment shaders. Scanning beam via uniform. Color-coded particles. | **High** |
| Kinetic Counter (Flip digits) | Framer Motion | Per-digit spring animation. Digits split into array, each wrapped in overflow-hidden container with animated translateY. | Medium |
| Barcode Laser Scan | Framer Motion | Animated scanning line (translateY 0%->100% loop) over canvas element. State-driven start/stop. | Medium |
| Waveform Sync | Framer Motion | Array of 5 divs with staggered scaleY animation cycling [0.2, 1, 0.2]. Toggle on/off state. | Low |
| Scan Success Ripple | CSS Animation | Radial gradient pulse expanding from center on successful scan. Single-fire keyframe. | Low |
| Button Press | Tailwind | `active:translate-y-[1px]` + color transition. Pure CSS. | Low |
| Input Focus Glow | Tailwind | `focus:border-accent-orange` transition on bottom-border inputs. | Low |
| Page Transitions | Framer Motion | `AnimatePresence` wrapping router outlet. Fade + slight translateY. | Low |
| Table Row Highlight | CSS Transition | Background color transition on hover. Low stock rows get pulsing red animation. | Low |
| Modal Enter/Exit | Framer Motion | Scale + opacity spring animation via AnimatePresence. | Low |

## State & Logic Plan

### Authentication & Roles
- **Simple in-memory auth** with localStorage session persistence
- Two hardcoded users: `admin/admin` (role: admin) and `operator/operator` (role: operator)
- Context-based auth provider wrapping the app
- Route guards redirect unauthenticated users to login
- Admin routes conditionally render based on `user.role === 'admin'`

### Offline-First Data Architecture (Dexie.js)
All warehouse data stored in IndexedDB via Dexie:

| Table | Schema | Description |
|-------|--------|-------------|
| `inventory` | `++id, sku, product, stock, location, updatedAt` | Master stock records |
| `orders` | `++id, orderId, status, requiredSkus, createdAt, updatedAt` | Daily orders |
| `returns` | `++id, orderId, sku, reason, processedAt` | Return log entries |
| `inbound` | `++id, sku, qty, bin, description, receivedAt` | Inbound receiving log |
| `auditLogs` | `++id, action, details, operator, timestamp` | Activity audit trail |
| `users` | `++id, username, role, createdAt` | Local user accounts |

### Data Flow
1. App boots → Dexie initializes with default seed data
2. All CRUD operations go directly to IndexedDB (no server)
3. Data mutations trigger React re-renders via Dexie hooks
4. Settings module provides "Export" (JSON/CSV) and "Import" for data portability
5. Google Sheets sync remains as optional cloud backup (future enhancement)

### Module Logic

**Dashboard**: Aggregated counts from inventory/orders tables. Auto-refresh on data changes.

**Inbound Receiving**: Form validates SKU → check existence → update stock (existing) or create new record. Log entry to `inbound` table.

**Inventory Hub**: Display full inventory table. Low stock (<10) highlighted. Inline editing via data table. Zone map is CSS grid with hover-to-highlight connection.

**Pick & Pack**: Show pending orders. Select order → display required SKUs. Scan/verify mode compares scanned SKUs against required. Match → deduct inventory, mark shipped, show success. Mismatch → error state.

**Returns**: Input original order ID (optional) + scan returned SKU. Select reason. Defective → log only (no restock). Other reasons → increment stock by 1. Update order status to "Returned".

**PDF Sequencer**: FileReader API reads PDF. Extract text per page. Regex match tracking IDs. Sort pages by user-provided sequence order. Generate downloadable PDF blob.

**Auditor**: Parse two text blocks (master vs scan) into sets. Compare and generate discrepancy report with color-coded results.

**Bulk Converter**: Split input lines. Simple uppercase + keyword mapping (no external API for offline capability).

**Settings**: Operator name, theme preferences, data export/import, session management.

**User Management (Admin only)**: CRUD for local users. Role assignment.

## Other Key Decisions

### No shadcn Table Component
The inventory and data views require ultra-dense tables with custom styling (1px gaps, custom row heights, inline editing). A custom DataTable component built from scratch with Tailwind will be more suitable than shadcn's Table which is too opinionated for this industrial aesthetic.

### PDF Processing
Since we cannot use PyPDF in a browser context, PDF Sequencer will use a simplified approach: FileReader reads text content, regex extracts tracking numbers. For actual PDF generation, we'll use a client-side approach with `jspdf` library to create sorted PDFs from extracted data.

### Barcode Scanning
Physical barcode scanning is simulated via text input (barcode scanners typically act as keyboard input). The BarcodeReader component provides a visual scanning animation for demonstration, but actual scanning uses a hidden text input that captures scanner output.

### Service Worker
A simple service worker (via Vite PWA plugin) will cache static assets for offline app loading. Data persistence is handled by IndexedDB (already offline).