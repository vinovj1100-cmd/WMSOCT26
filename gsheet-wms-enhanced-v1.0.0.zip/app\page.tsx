import { auth } from "@/lib/auth";
import { headers } from "next/headers";
import { redirect } from "next/navigation";
import { getOrders } from "@/app/actions/orders";
import { getInventory, getLowStockItems } from "@/app/actions/inventory";
import { getAlerts } from "@/app/actions/alerts";
import { db } from "@/lib/db";
import { userRole } from "@/lib/db/schema";
import { eq } from "drizzle-orm";
import { OrderCard } from "@/components/order-card";
import { AlertsPanel } from "@/components/alerts-panel";
import { Package, AlertTriangle, TrendingUp } from "lucide-react";
import Link from "next/link";
import { Button } from "@/components/ui/button";

export const metadata = {
  title: "Dashboard - G-SHEET WMS",
  description: "Warehouse management system dashboard",
};

export default async function Dashboard() {
  const session = await auth.api.getSession({ headers: await headers() });
  if (!session?.user) redirect("/sign-in");

  const userRoleData = await db
    .select()
    .from(userRole)
    .where(eq(userRole.userId, session.user.id));
  const role = userRoleData[0]?.role || "staff";

  const [orders, inventory, alerts, lowStockItems] = await Promise.all([
    getOrders(),
    getInventory(),
    getAlerts(),
    getLowStockItems(),
  ]);

  const stats = {
    totalOrders: orders.length,
    receivedOrders: orders.filter((o) => o.status === "received").length,
    pickedOrders: orders.filter((o) => o.status === "picked").length,
    shippedOrders: orders.filter((o) => o.status === "shipped").length,
    lowStockItems: lowStockItems.length,
    totalInventory: inventory.length,
  };

  return (
    <div className="min-h-screen bg-background">
      <header className="bg-primary text-primary-foreground shadow-md">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold">G-SHEET WMS</h1>
              <p className="text-sm opacity-90 mt-1">
                Welcome back, {session.user.name || session.user.email}
              </p>
            </div>
            <div className="flex items-center gap-4">
              <AlertsPanel />
              <Link href="/profile">
                <Button variant="secondary" size="sm">
                  Profile
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          <div className="bg-white rounded-lg border border-border p-6 shadow-sm">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-muted-foreground text-sm">Total Orders</p>
                <p className="text-3xl font-bold mt-1">{stats.totalOrders}</p>
              </div>
              <Package className="w-8 h-8 text-primary opacity-20" />
            </div>
          </div>

          <div className="bg-white rounded-lg border border-border p-6 shadow-sm">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-muted-foreground text-sm">Pending Receipt</p>
                <p className="text-3xl font-bold mt-1">{stats.receivedOrders}</p>
              </div>
              <TrendingUp className="w-8 h-8 text-blue-500 opacity-20" />
            </div>
          </div>

          <div className="bg-white rounded-lg border border-border p-6 shadow-sm">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-muted-foreground text-sm">Ready to Ship</p>
                <p className="text-3xl font-bold mt-1">{stats.pickedOrders}</p>
              </div>
              <Package className="w-8 h-8 text-accent opacity-20" />
            </div>
          </div>

          <div className="bg-white rounded-lg border border-border p-6 shadow-sm">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-muted-foreground text-sm">Low Stock Items</p>
                <p className="text-3xl font-bold mt-1 text-red-600">
                  {stats.lowStockItems}
                </p>
              </div>
              <AlertTriangle className="w-8 h-8 text-red-500 opacity-20" />
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2">
            <div className="mb-6">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-2xl font-bold">
                  {role === "admin" ? "All Orders" : "Assigned Orders"}
                </h2>
                {role === "admin" && (
                  <Link href="/orders/new">
                    <Button size="sm">New Order</Button>
                  </Link>
                )}
              </div>
              <div className="space-y-4">
                {orders.slice(0, 6).map((order) => (
                  <OrderCard key={order.id} order={order} />
                ))}
              </div>
              {orders.length > 6 && (
                <Link href="/orders" className="block mt-4">
                  <Button variant="outline" className="w-full">
                    View All Orders ({orders.length})
                  </Button>
                </Link>
              )}
            </div>
          </div>

          <div className="space-y-6">
            {lowStockItems.length > 0 && (
              <div className="bg-red-50 border border-red-200 rounded-lg p-4">
                <h3 className="font-semibold text-red-900 mb-3 flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4" />
                  Low Stock Alert
                </h3>
                <div className="space-y-2">
                  {lowStockItems.slice(0, 5).map((item) => (
                    <div key={item.id} className="text-sm">
                      <p className="font-medium text-red-900">
                        {item.productName}
                      </p>
                      <p className="text-red-700">
                        {item.quantity} / {item.minimumLevel} units
                      </p>
                    </div>
                  ))}
                </div>
                {lowStockItems.length > 5 && (
                  <Link href="/inventory">
                    <Button variant="outline" size="sm" className="w-full mt-3">
                      View All Low Stock
                    </Button>
                  </Link>
                )}
              </div>
            )}

            <div className="bg-white border border-border rounded-lg p-4">
              <h3 className="font-semibold mb-3 flex items-center gap-2">
                <Package className="w-4 h-4" />
                Inventory Overview
              </h3>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Total SKUs</span>
                  <span className="font-semibold">{stats.totalInventory}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Low Stock</span>
                  <span className="font-semibold text-red-600">
                    {stats.lowStockItems}
                  </span>
                </div>
              </div>
              {role === "admin" && (
                <Link href="/inventory" className="block mt-4">
                  <Button variant="outline" size="sm" className="w-full">
                    Manage Inventory
                  </Button>
                </Link>
              )}
            </div>

            <div className="bg-white border border-border rounded-lg p-4">
              <h3 className="font-semibold mb-3">Recent Activity</h3>
              <div className="space-y-2 text-sm">
                {alerts.slice(0, 3).map((alert) => (
                  <div key={alert.id} className="p-2 bg-gray-50 rounded text-xs">
                    <p className="font-medium">{alert.title}</p>
                    <p className="text-muted-foreground truncate">
                      {alert.message}
                    </p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
