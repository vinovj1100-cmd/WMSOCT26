import { auth } from "@/lib/auth";
import { headers } from "next/headers";
import { redirect } from "next/navigation";
import { db } from "@/lib/db";
import { userRole } from "@/lib/db/schema";
import { eq } from "drizzle-orm";
import { getSyncHistory } from "@/app/actions/sheets";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { AlertsPanel } from "@/components/alerts-panel";
import { SyncButton } from "@/components/sync-button";
import { Settings, RotateCcw, Database } from "lucide-react";

export const metadata = {
  title: "Admin Settings - G-SHEET WMS",
};

export default async function AdminSettingsPage() {
  const session = await auth.api.getSession({ headers: await headers() });
  if (!session?.user) redirect("/sign-in");

  const userRoleData = await db
    .select()
    .from(userRole)
    .where(eq(userRole.userId, session.user.id));
  const role = userRoleData[0]?.role || "staff";

  if (role !== "admin") {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold mb-2">Access Denied</h1>
          <p className="text-muted-foreground mb-4">
            Only admins can access this page
          </p>
          <Link href="/">
            <Button>Back to Dashboard</Button>
          </Link>
        </div>
      </div>
    );
  }

  const syncHistory = await getSyncHistory(10);

  return (
    <div className="min-h-screen bg-background">
      <header className="bg-primary text-primary-foreground shadow-md">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Settings className="w-6 h-6" />
              <div>
                <h1 className="text-2xl font-bold">Admin Settings</h1>
                <p className="text-sm opacity-90">
                  Manage system configuration and integrations
                </p>
              </div>
            </div>
            <div className="flex items-center gap-4">
              <AlertsPanel />
              <Link href="/">
                <Button variant="secondary" size="sm">
                  Dashboard
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Settings */}
          <div className="lg:col-span-2 space-y-6">
            {/* Google Sheets Integration */}
            <div className="bg-white border border-border rounded-lg p-6">
              <h2 className="text-xl font-bold mb-2 flex items-center gap-2">
                <Database className="w-5 h-5" />
                Google Sheets Integration
              </h2>
              <p className="text-sm text-muted-foreground mb-6">
                Sync orders and inventory with your Google Sheets in real-time
              </p>

              <div className="space-y-4 mb-6">
                <div className="bg-gray-50 rounded-lg p-4">
                  <label className="text-sm font-medium">Sheet ID</label>
                  <div className="mt-2 p-2 bg-white border border-border rounded text-sm font-mono">
                    {process.env.GOOGLE_SHEETS_ID || "Not configured"}
                  </div>
                  <p className="text-xs text-muted-foreground mt-2">
                    Set GOOGLE_SHEETS_ID environment variable to enable
                  </p>
                </div>

                <div className="bg-gray-50 rounded-lg p-4">
                  <label className="text-sm font-medium">Sync Direction</label>
                  <div className="mt-2 flex gap-2">
                    <Button size="sm" variant="outline" className="flex-1">
                      ⬇️ Pull from Sheet
                    </Button>
                    <Button size="sm" variant="outline" className="flex-1">
                      ⬆️ Push to Sheet
                    </Button>
                    <SyncButton />
                  </div>
                  <p className="text-xs text-muted-foreground mt-2">
                    Pull: Import orders and inventory from Sheet
                    <br />
                    Push: Export current data to Sheet
                  </p>
                </div>
              </div>

              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                <h3 className="font-semibold text-sm text-blue-900 mb-2">
                  Setup Instructions
                </h3>
                <ol className="text-xs text-blue-900 space-y-1 list-decimal list-inside">
                  <li>Create a Google Sheets document</li>
                  <li>Enable the Google Sheets API</li>
                  <li>Create a service account and download credentials</li>
                  <li>Set GOOGLE_SHEETS_ID environment variable</li>
                  <li>Use bi-directional sync to keep data in sync</li>
                </ol>
              </div>
            </div>

            {/* System Configuration */}
            <div className="bg-white border border-border rounded-lg p-6">
              <h2 className="text-xl font-bold mb-4">System Configuration</h2>
              <div className="space-y-4">
                <div className="bg-gray-50 rounded-lg p-4">
                  <label className="text-sm font-medium">
                    Auto-Sync Interval (minutes)
                  </label>
                  <input
                    type="number"
                    defaultValue="5"
                    className="mt-2 w-full p-2 border border-border rounded"
                  />
                  <p className="text-xs text-muted-foreground mt-2">
                    How often to automatically sync with Google Sheets
                  </p>
                </div>

                <div className="flex gap-2">
                  <Button size="sm">Save Configuration</Button>
                  <Button size="sm" variant="outline">
                    Reset to Defaults
                  </Button>
                </div>
              </div>
            </div>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Sync Status */}
            <div className="bg-white border border-border rounded-lg p-6">
              <h3 className="text-lg font-bold mb-4 flex items-center gap-2">
                <RotateCcw className="w-4 h-4" />
                Recent Syncs
              </h3>
              <div className="space-y-3">
                {syncHistory.length === 0 ? (
                  <p className="text-sm text-muted-foreground">
                    No sync history yet
                  </p>
                ) : (
                  syncHistory.map((log) => (
                    <div
                      key={log.id}
                      className={`p-3 rounded-lg text-xs ${
                        log.status === "success"
                          ? "bg-green-50 border border-green-200"
                          : "bg-red-50 border border-red-200"
                      }`}
                    >
                      <div className="flex items-center justify-between mb-1">
                        <span className="font-medium capitalize">
                          {log.direction}
                        </span>
                        <span
                          className={`px-2 py-0.5 rounded text-xs font-medium ${
                            log.status === "success"
                              ? "bg-green-100 text-green-800"
                              : "bg-red-100 text-red-800"
                          }`}
                        >
                          {log.status}
                        </span>
                      </div>
                      {log.recordsProcessed && (
                        <p className="text-xs opacity-75">
                          {log.recordsProcessed} records
                        </p>
                      )}
                      {log.errorMessage && (
                        <p className="text-xs opacity-75">
                          Error: {log.errorMessage}
                        </p>
                      )}
                      <p className="text-xs opacity-50 mt-1">
                        {new Date(log.createdAt).toLocaleString()}
                      </p>
                    </div>
                  ))
                )}
              </div>
            </div>

            {/* Quick Stats */}
            <div className="bg-white border border-border rounded-lg p-6">
              <h3 className="text-lg font-bold mb-4">Integration Status</h3>
              <div className="space-y-3 text-sm">
                <div className="flex items-center justify-between">
                  <span className="text-muted-foreground">Google Sheets</span>
                  <span
                    className={`px-2 py-1 rounded text-xs font-medium ${
                      process.env.GOOGLE_SHEETS_ID
                        ? "bg-green-100 text-green-800"
                        : "bg-gray-100 text-gray-800"
                    }`}
                  >
                    {process.env.GOOGLE_SHEETS_ID ? "✓ Enabled" : "✗ Disabled"}
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-muted-foreground">Database</span>
                  <span className="px-2 py-1 rounded text-xs font-medium bg-green-100 text-green-800">
                    ✓ Connected
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-muted-foreground">API Endpoints</span>
                  <span className="px-2 py-1 rounded text-xs font-medium bg-green-100 text-green-800">
                    ✓ Active
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
