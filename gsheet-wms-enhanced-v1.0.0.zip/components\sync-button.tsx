"use client";

import { useState } from "react";
import { Button } from "@/components/ui/button";
import { pushToGoogleSheets } from "@/app/actions/sheets";
import { RefreshCw } from "lucide-react";

export function SyncButton() {
  const [isLoading, setIsLoading] = useState(false);
  const [message, setMessage] = useState<string | null>(null);

  const handleSync = async () => {
    setIsLoading(true);
    setMessage(null);

    try {
      const result = await pushToGoogleSheets();
      setMessage(`✓ ${result.message}`);
      setTimeout(() => setMessage(null), 5000);
    } catch (error) {
      const errorMessage =
        error instanceof Error ? error.message : "Sync failed";
      setMessage(`✗ Error: ${errorMessage}`);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="flex flex-col gap-2">
      <Button
        size="sm"
        onClick={handleSync}
        disabled={isLoading}
        variant="outline"
        className="flex-1 gap-2"
      >
        <RefreshCw className={`w-4 h-4 ${isLoading ? "animate-spin" : ""}`} />
        {isLoading ? "Syncing..." : "Sync Now"}
      </Button>
      {message && (
        <p className="text-xs text-center p-2 rounded bg-gray-100">
          {message}
        </p>
      )}
    </div>
  );
}
