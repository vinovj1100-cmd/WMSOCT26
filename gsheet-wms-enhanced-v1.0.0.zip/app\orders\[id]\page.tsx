import { auth } from "@/lib/auth";
import { headers } from "next/headers";
import { redirect } from "next/navigation";
import { getOrderById, updateOrderStatus, addOrderNote } from "@/app/actions/orders";
import { db } from "@/lib/db";
import { userRole } from "@/lib/db/schema";
import { eq } from "drizzle-orm";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { AlertsPanel } from "@/components/alerts-panel";
import { ChevronLeft, Calendar, User, Phone, FileText } from "lucide-react";

export const metadata = {
  title: "Order Details - G-SHEET WMS",
};

export default async function OrderDetailPage({
  params,
}: {
  params: { id: string };
}) {
  const session = await auth.api.getSession({ headers: await headers() });
  if (!session?.user) redirect("/sign-in");

  const userRoleData = await db
    .select()
    .from(userRole)
    .where(eq(userRole.userId, session.user.id));
  const role = userRoleData[0]?.role || "staff";

  const order = await getOrderById(params.id);
  if (!order) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold mb-2">Order Not Found</h1>
          <Link href="/orders">
            <Button>Back to Orders</Button>
          </Link>
        </div>
      </div>
    );
  }

  const statusColors: Record<string, string> = {
    received: "bg-blue-100 text-blue-900",
    picked: "bg-yellow-100 text-yellow-900",
    packed: "bg-purple-100 text-purple-900",
    shipped: "bg-green-100 text-green-900",
  };

  const statusFlow = ["received", "picked", "packed", "shipped"];
  const currentIndex = statusFlow.indexOf(order.status);

  return (
    <div className="min-h-screen bg-background">
      <header className="bg-primary text-primary-foreground shadow-md">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Link href="/orders">
                <Button variant="secondary" size="icon">
                  <ChevronLeft className="w-4 h-4" />
                </Button>
              </Link>
              <div>
                <h1 className="text-2xl font-bold">Order {order.orderNumber}</h1>
              </div>
            </div>
            <AlertsPanel />
          </div>
        </div>
      </header>

      <main className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2">
            {/* Order Status */}
            <div className="bg-white border border-border rounded-lg p-6 mb-6">
              <h2 className="text-lg font-semibold mb-4">Order Status</h2>
              <div className="flex items-center gap-2 mb-4">
                <span
                  className={`px-4 py-2 rounded-lg font-semibold text-sm ${statusColors[order.status]}`}
                >
                  {order.status.toUpperCase()}
                </span>
              </div>

              {/* Status Flow */}
              <div className="flex items-center justify-between mb-6">
                {statusFlow.map((status, index) => (
                  <div key={status} className="flex flex-col items-center">
                    <div
                      className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-semibold ${
                        index <= currentIndex
                          ? "bg-primary text-primary-foreground"
                          : "bg-gray-200 text-gray-600"
                      }`}
                    >
                      {index + 1}
                    </div>
                    <span className="text-xs mt-2 font-medium">{status}</span>
                  </div>
                ))}
              </div>

              {/* Timeline */}
              <div className="space-y-3">
                {order.receivedAt && (
                  <div className="flex items-center gap-2 text-sm">
                    <Calendar className="w-4 h-4 text-primary" />
                    <span>Received: {new Date(order.receivedAt).toLocaleString()}</span>
                  </div>
                )}
                {order.pickedAt && (
                  <div className="flex items-center gap-2 text-sm">
                    <Calendar className="w-4 h-4 text-primary" />
                    <span>Picked: {new Date(order.pickedAt).toLocaleString()}</span>
                  </div>
                )}
                {order.packedAt && (
                  <div className="flex items-center gap-2 text-sm">
                    <Calendar className="w-4 h-4 text-primary" />
                    <span>Packed: {new Date(order.packedAt).toLocaleString()}</span>
                  </div>
                )}
                {order.shippedAt && (
                  <div className="flex items-center gap-2 text-sm">
                    <Calendar className="w-4 h-4 text-primary" />
                    <span>Shipped: {new Date(order.shippedAt).toLocaleString()}</span>
                  </div>
                )}
              </div>
            </div>

            {/* Items */}
            <div className="bg-white border border-border rounded-lg p-6 mb-6">
              <h2 className="text-lg font-semibold mb-4">Items ({order.items.length})</h2>
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b border-border">
                      <th className="text-left py-2 px-4 text-sm font-semibold">SKU</th>
                      <th className="text-left py-2 px-4 text-sm font-semibold">
                        Required
                      </th>
                      <th className="text-left py-2 px-4 text-sm font-semibold">Picked</th>
                      <th className="text-left py-2 px-4 text-sm font-semibold">Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    {order.items.map((item) => (
                      <tr key={item.id} className="border-b border-border">
                        <td className="py-3 px-4 font-mono text-sm">{item.skuId}</td>
                        <td className="py-3 px-4">{item.quantity}</td>
                        <td className="py-3 px-4">{item.pickedQuantity}</td>
                        <td className="py-3 px-4">
                          <span
                            className={`px-2 py-1 rounded text-xs font-medium ${
                              item.status === "pending"
                                ? "bg-gray-100 text-gray-800"
                                : "bg-green-100 text-green-800"
                            }`}
                          >
                            {item.status}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Customer Info */}
            <div className="bg-white border border-border rounded-lg p-6">
              <h3 className="text-lg font-semibold mb-4">Customer Information</h3>
              <div className="space-y-3">
                {order.customerName && (
                  <div className="flex items-start gap-3">
                    <User className="w-4 h-4 mt-1 text-muted-foreground" />
                    <div>
                      <p className="text-xs text-muted-foreground">Name</p>
                      <p className="font-medium">{order.customerName}</p>
                    </div>
                  </div>
                )}
                {order.customerPhone && (
                  <div className="flex items-start gap-3">
                    <Phone className="w-4 h-4 mt-1 text-muted-foreground" />
                    <div>
                      <p className="text-xs text-muted-foreground">Phone</p>
                      <p className="font-medium">{order.customerPhone}</p>
                    </div>
                  </div>
                )}
              </div>
            </div>

            {/* Assigned Staff */}
            {order.assignedUser && (
              <div className="bg-white border border-border rounded-lg p-6">
                <h3 className="text-lg font-semibold mb-4">Assigned To</h3>
                <div className="space-y-2">
                  <p className="font-medium">{order.assignedUser.name}</p>
                  <p className="text-sm text-muted-foreground">
                    {order.assignedUser.email}
                  </p>
                </div>
              </div>
            )}

            {/* Notes */}
            {order.notes && (
              <div className="bg-white border border-border rounded-lg p-6">
                <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
                  <FileText className="w-4 h-4" />
                  Notes
                </h3>
                <div className="text-sm whitespace-pre-wrap text-muted-foreground">
                  {order.notes}
                </div>
              </div>
            )}

            {/* Order Dates */}
            <div className="bg-white border border-border rounded-lg p-6">
              <h3 className="text-lg font-semibold mb-4">Dates</h3>
              <div className="space-y-2 text-sm">
                <div>
                  <p className="text-muted-foreground">Created</p>
                  <p className="font-medium">
                    {new Date(order.createdAt).toLocaleString()}
                  </p>
                </div>
                <div>
                  <p className="text-muted-foreground">Last Updated</p>
                  <p className="font-medium">
                    {new Date(order.updatedAt).toLocaleString()}
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
