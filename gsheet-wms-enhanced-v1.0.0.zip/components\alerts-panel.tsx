"use client";

import { useEffect, useState } from "react";
import { getAlerts, markAlertAsRead } from "@/app/actions/alerts";
import { Bell, AlertCircle, AlertTriangle, Info } from "lucide-react";
import { Button } from "@/components/ui/button";

const severityIcons: Record<string, React.ReactNode> = {
  info: <Info className="w-4 h-4" />,
  warning: <AlertTriangle className="w-4 h-4" />,
  error: <AlertCircle className="w-4 h-4" />,
};

const severityColors: Record<string, string> = {
  info: "bg-blue-50 border-blue-200 text-blue-900",
  warning: "bg-yellow-50 border-yellow-200 text-yellow-900",
  error: "bg-red-50 border-red-200 text-red-900",
};

export function AlertsPanel() {
  const [alerts, setAlerts] = useState<any[]>([]);
  const [isOpen, setIsOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    loadAlerts();
    const interval = setInterval(loadAlerts, 30000);
    return () => clearInterval(interval);
  }, []);

  const loadAlerts = async () => {
    try {
      const data = await getAlerts();
      setAlerts(data);
    } catch (error) {
      console.error("Failed to load alerts", error);
    } finally {
      setIsLoading(false);
    }
  };

  const unreadCount = alerts.filter((a) => !a.readAt).length;

  return (
    <div className="relative">
      <Button
        variant="outline"
        size="icon"
        onClick={() => setIsOpen(!isOpen)}
        className="relative"
      >
        <Bell className="w-4 h-4" />
        {unreadCount > 0 && (
          <span className="absolute top-0 right-0 w-2 h-2 bg-red-500 rounded-full"></span>
        )}
      </Button>

      {isOpen && (
        <div className="absolute right-0 top-10 w-96 max-h-96 bg-white border border-gray-200 rounded-lg shadow-lg z-50 overflow-y-auto">
          <div className="p-4 border-b border-gray-100 sticky top-0 bg-white">
            <h3 className="font-semibold text-sm">
              Alerts {unreadCount > 0 && `(${unreadCount} unread)`}
            </h3>
          </div>

          {isLoading ? (
            <div className="p-4 text-center text-gray-500 text-sm">Loading...</div>
          ) : alerts.length === 0 ? (
            <div className="p-4 text-center text-gray-500 text-sm">
              No alerts at this time
            </div>
          ) : (
            <div className="divide-y divide-gray-100">
              {alerts.map((alert) => (
                <div
                  key={alert.id}
                  className={`p-3 border-l-4 border-gray-200 ${severityColors[alert.severity] || "bg-gray-50"}`}
                >
                  <div className="flex items-start gap-3">
                    <div className="mt-1">{severityIcons[alert.severity]}</div>
                    <div className="flex-1 min-w-0">
                      <p className="text-xs font-semibold">{alert.title}</p>
                      <p className="text-xs mt-1 opacity-80">{alert.message}</p>
                      <p className="text-xs mt-2 opacity-50">
                        {new Date(alert.createdAt).toLocaleString()}
                      </p>
                    </div>
                    {!alert.readAt && (
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={async () => {
                          await markAlertAsRead(alert.id);
                          loadAlerts();
                        }}
                        className="text-xs"
                      >
                        Dismiss
                      </Button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
