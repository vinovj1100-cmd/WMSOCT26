import { NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { sql } from 'drizzle-orm'

export const dynamic = 'force-dynamic'

export async function GET() {
  const startTime = Date.now()
  
  try {
    // Check database connectivity
    await db.execute(sql`SELECT 1`)
    
    const dbLatency = Date.now() - startTime
    
    return NextResponse.json(
      {
        status: 'healthy',
        timestamp: new Date().toISOString(),
        version: process.env.npm_package_version || '0.1.0',
        environment: process.env.NODE_ENV,
        checks: {
          database: {
            status: 'up',
            latencyMs: dbLatency,
          },
          server: {
            status: 'up',
            uptime: process.uptime(),
          },
        },
      },
      { status: 200 }
    )
  } catch (error) {
    return NextResponse.json(
      {
        status: 'unhealthy',
        timestamp: new Date().toISOString(),
        checks: {
          database: {
            status: 'down',
            error: error instanceof Error ? error.message : 'Unknown error',
          },
          server: {
            status: 'up',
            uptime: process.uptime(),
          },
        },
      },
      { status: 503 }
    )
  }
}
