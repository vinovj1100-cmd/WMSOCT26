"use server";

import { auth } from "@/lib/auth";
import { db } from "@/lib/db";
import {
  inventory,
  inventoryMovements,
  alerts,
  userRole,
} from "@/lib/db/schema";
import { eq, lt, desc, and, isNull } from "drizzle-orm";
import { headers } from "next/headers";
import { revalidatePath } from "next/cache";
import { v4 as uuidv4 } from "uuid";

async function getUserId() {
  const session = await auth.api.getSession({ headers: await headers() });
  if (!session?.user) throw new Error("Unauthorized");
  return session.user.id;
}

async function getUserRole(userId: string) {
  const roleData = await db
    .select()
    .from(userRole)
    .where(eq(userRole.userId, userId));
  return roleData[0]?.role || "staff";
}

export async function getInventory() {
  return db.query.inventory.findMany({
    orderBy: [desc(inventory.productName)],
    with: {
      lastUpdatedUser: {
        columns: {
          name: true,
          email: true,
        },
      },
    },
  });
}

export async function getInventoryBySku(skuId: string) {
  return db.query.inventory.findFirst({
    where: eq(inventory.skuId, skuId),
    with: {
      movements: {
        orderBy: [desc(inventoryMovements.createdAt)],
      },
    },
  });
}

export async function updateInventoryQuantity(
  skuId: string,
  quantityChange: number,
  reference?: string
) {
  const userId = await getUserId();
  const role = await getUserRole(userId);

  if (role !== "admin") throw new Error("Only admins can update inventory");

  const currentInventory = await db
    .select()
    .from(inventory)
    .where(eq(inventory.skuId, skuId));

  if (!currentInventory[0]) throw new Error("SKU not found");

  const newQuantity = currentInventory[0].quantity + quantityChange;

  await db
    .update(inventory)
    .set({
      quantity: newQuantity,
      lastUpdatedBy: userId,
      updatedAt: new Date(),
    })
    .where(eq(inventory.skuId, skuId));

  // Log the movement
  await db.insert(inventoryMovements).values({
    id: uuidv4(),
    skuId,
    type: quantityChange > 0 ? "stock_in" : "adjustment",
    quantity: Math.abs(quantityChange),
    reference: reference || `Adjustment`,
    createdBy: userId,
  });

  // Check if stock is low and create alert
  if (newQuantity <= currentInventory[0].minimumLevel) {
    const existingAlert = await db
      .select()
      .from(alerts)
      .where(
        and(
          eq(alerts.relatedId, skuId),
          eq(alerts.type, "low_stock"),
          isNull(alerts.readBy)
        )
      );

    if (existingAlert.length === 0) {
      await db.insert(alerts).values({
        id: uuidv4(),
        type: "low_stock",
        severity: "warning",
        title: `Low Stock Alert: ${currentInventory[0].productName}`,
        message: `Stock level for ${currentInventory[0].productName} (${skuId}) is now ${newQuantity} units, below minimum of ${currentInventory[0].minimumLevel}`,
        relatedId: skuId,
      });
    }
  }

  revalidatePath("/");
}

export async function getLowStockItems() {
  return db
    .select()
    .from(inventory)
    .where(lt(inventory.quantity, inventory.minimumLevel))
    .orderBy(desc(inventory.quantity));
}

export async function getInventoryMovements(skuId?: string) {
  if (skuId) {
    return db.query.inventoryMovements.findMany({
      where: eq(inventoryMovements.skuId, skuId),
      orderBy: [desc(inventoryMovements.createdAt)],
      with: {
        createdByUser: {
          columns: {
            name: true,
          },
        },
      },
    });
  }

  return db.query.inventoryMovements.findMany({
    orderBy: [desc(inventoryMovements.createdAt)],
    with: {
      createdByUser: {
        columns: {
          name: true,
        },
      },
    },
  });
}
