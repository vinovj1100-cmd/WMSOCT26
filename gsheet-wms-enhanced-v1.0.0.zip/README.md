# G-SHEET WMS - Warehouse Management System

A comprehensive, real-time warehouse management system with Google Sheets integration, built for Ozon fulfillment order processing. Features bi-directional sync, role-based access control, inventory management, and multi-device support.

## Features

### Core WMS Functionality
- **Order Management**: Complete order lifecycle tracking (Received → Picked → Packed → Shipped)
- **Inventory Management**: Real-time stock tracking with low stock alerts
- **Staff Workflow**: Assigned orders dashboard for warehouse staff
- **Admin Control**: Comprehensive admin dashboard for system management
- **Multi-Device Access**: Fully responsive design for desktop, tablet, and mobile devices
- **Real-time Alerts**: Notifications for low stock, order delays, QC issues, and system errors

### Integration & Sync
- **Google Sheets Bi-directional Sync**: 
  - Pull: Import orders and inventory from Google Sheets
  - Push: Export current data to Google Sheets
  - Sync history tracking and logging
- **Automatic Sync**: Configurable auto-sync intervals (default: 5 minutes)
- **Conflict Resolution**: Automatic handling of data conflicts during sync

### Security & Access Control
- **Authentication**: Email/password authentication with Better Auth
- **Role-Based Access**: Staff and Admin roles with distinct permissions
- **Session Management**: Secure session handling across multiple devices
- **Data Scoping**: User-scoped data access to prevent unauthorized access

## Architecture

### Tech Stack
- **Frontend**: Next.js 16 with React 19.2
- **Backend**: Next.js Server Actions
- **Database**: Neon PostgreSQL with Drizzle ORM
- **Auth**: Better Auth (email/password)
- **UI**: Tailwind CSS v4 with shadcn components
- **Styling**: Professional blue/orange color scheme optimized for operations

### Database Schema

#### Core Tables
- `user` - User accounts and profiles
- `session` - User session management
- `account` - Auth provider accounts
- `verification` - Email verification

#### WMS Tables
- `userRole` - User role assignment (staff/admin)
- `orders` - Order records with status tracking
- `orderItems` - Individual SKUs within orders
- `inventory` - Stock levels by SKU
- `inventoryMovements` - Audit trail of inventory changes
- `alerts` - System alerts and notifications
- `sheetSyncLog` - Google Sheets sync history

## Setup Instructions

### Prerequisites
- Node.js 18+ 
- pnpm package manager
- Neon PostgreSQL database
- Google Sheets API credentials (for integration)

### 1. Environment Setup
Create a `.env.local` file with:
```
DATABASE_URL=postgresql://user:password@host/database
BETTER_AUTH_SECRET=<generate with: openssl rand -base64 32>
BETTER_AUTH_URL=http://localhost:3000
GOOGLE_SHEETS_ID=<your-google-sheet-id>
```

### 2. Install Dependencies
```bash
pnpm install
```

### 3. Database Setup
The Neon integration in v0 handles schema creation through the MCP tools. Tables are automatically created via `neon_run_sql` commands.

### 4. Run Development Server
```bash
pnpm dev
```

Visit `http://localhost:3000` and create your first admin account.

## Usage Guide

### For Warehouse Staff
1. **Sign In**: Use email/password credentials
2. **View Assigned Orders**: Dashboard shows your assigned orders
3. **Process Orders**: Move orders through workflow stages
4. **Track Inventory**: View real-time stock levels
5. **Receive Alerts**: Get notified of urgent issues

### For Administrators
1. **Sign In**: Admin account with full system access
2. **Dashboard**: Overview of all orders, inventory, and alerts
3. **Order Management**: Create, assign, and track all orders
4. **Inventory Management** (`/inventory`): Manage stock levels and set minimum thresholds
5. **User Management** (`/admin/users`): Manage staff and admin access
6. **System Settings** (`/admin/settings`): Configure Google Sheets sync and system parameters

### Google Sheets Integration

#### Setup
1. Create a Google Sheets document
2. Enable Google Sheets API in Google Cloud Console
3. Create a service account and download JSON credentials
4. Set `GOOGLE_SHEETS_ID` environment variable

#### Sync Operations
- **Pull from Sheet**: Import orders and inventory updates from Sheet
- **Push to Sheet**: Export current WMS data to Sheet
- **Auto-Sync**: Automatic bi-directional sync at configured intervals

#### Data Format
**Orders Sheet**:
- Order Number | Status | Customer Name | Phone | Items | Created | Notes

**Inventory Sheet**:
- SKU | Product Name | Quantity | Min Level | Location

## API Endpoints

### Authentication
- `POST /api/auth/sign-up` - Create new account
- `POST /api/auth/sign-in` - Login
- `POST /api/auth/sign-out` - Logout

### Server Actions
- `/app/actions/orders.ts` - Order management
- `/app/actions/inventory.ts` - Inventory management
- `/app/actions/alerts.ts` - Alert management
- `/app/actions/sheets.ts` - Google Sheets sync

## Pages & Routes

```
/                          - Dashboard (main)
/sign-in                   - Login page
/sign-up                   - Registration page
/profile                   - User profile
/orders                    - Orders list (grouped by status)
/orders/[id]              - Order details
/inventory                 - Inventory management (admin only)
/admin/users              - User management (admin only)
/admin/settings           - System settings (admin only)
```

## Features Implemented

### Order Processing
- [x] Order status tracking (Received → Picked → Packed → Shipped)
- [x] Order assignment to staff
- [x] Order notes and comments
- [x] Timeline tracking (timestamps for each stage)
- [x] Item-level tracking within orders

### Inventory Management
- [x] Real-time stock tracking
- [x] Low stock alerts (configurable thresholds)
- [x] Inventory movement audit trail
- [x] Location tracking for SKUs

### Alerts & Notifications
- [x] Low stock alerts
- [x] Order delay detection
- [x] Error tracking
- [x] QC issue alerts
- [x] Alert dismissal and read tracking
- [x] Alert panel with real-time updates

### Multi-Device Support
- [x] Responsive design (mobile, tablet, desktop)
- [x] Touch-friendly interface
- [x] Session management across devices
- [x] Mobile-optimized dashboard

### Admin Features
- [x] User management
- [x] Role-based access control
- [x] System configuration
- [x] Sync history and logging
- [x] Analytics dashboard

## Development

### File Structure
```
/app
  /actions          - Server actions (orders, inventory, alerts, sheets)
  /api/auth        - Authentication endpoints
  /admin           - Admin pages (users, settings)
  /orders          - Order pages
  /inventory       - Inventory page
  /profile         - Profile page
  page.tsx         - Main dashboard
/components
  auth-form.tsx    - Auth form component
  order-card.tsx   - Order display component
  alerts-panel.tsx - Alerts sidebar
  sync-button.tsx  - Google Sheets sync button
  /ui              - shadcn components
/lib
  auth.ts          - Better Auth config
  auth-client.ts   - Auth client
  /db              - Database setup
    schema.ts      - Drizzle schema
    index.ts       - Drizzle client
```

### Adding New Features

1. **Add Database Table**:
   - Define schema in `lib/db/schema.ts`
   - Create with `neon_run_sql` command

2. **Create Server Action**:
   - Add to `/app/actions/[feature].ts`
   - Use `getUserId()` for authorization
   - Include role-based checks

3. **Build UI Component**:
   - Create in `/components/[feature].tsx`
   - Use shadcn components
   - Follow Tailwind conventions

## Troubleshooting

### Database Connection Issues
- Verify `DATABASE_URL` is correct
- Check Neon project status
- Ensure IP whitelist allows connection

### Auth Issues
- Generate new `BETTER_AUTH_SECRET` if needed
- Clear browser cookies and try again
- Check session expiration

### Google Sheets Sync Failures
- Verify `GOOGLE_SHEETS_ID` is set
- Check service account permissions
- Review sync log for error details

### Deployment
- Environment variables must be set in Vercel project settings
- Database connections should use Neon serverless (already configured)
- Enable CORS if calling API from different domain

## Performance Optimization

- Server-side data fetching with Next.js 16
- Revalidation of cached data after mutations
- Responsive images and optimized assets
- Database query optimization with indexes
- Client-side caching with SWR patterns

## Security Considerations

- All user data scoped by userId (no RLS on Neon)
- Server actions handle authorization checks
- Session tokens signed with BETTER_AUTH_SECRET
- Email verification before account activation
- Rate limiting on auth endpoints (via Better Auth)

## Future Enhancements

- Real-time WebSocket updates (vs polling)
- Barcode/QR code scanning for picking
- Advanced analytics and reporting
- Export functionality (PDF, CSV)
- Mobile app (React Native)
- Two-factor authentication
- Audit logging for compliance
- Advanced Google Sheets mapping

## Support & Documentation

- [Next.js Documentation](https://nextjs.org/docs)
- [Better Auth Docs](https://www.betterauth.dev)
- [Drizzle ORM](https://orm.drizzle.team)
- [Tailwind CSS](https://tailwindcss.com)
- [shadcn/ui Components](https://ui.shadcn.com)

## License

Proprietary - Ozon Fulfillment WMS
