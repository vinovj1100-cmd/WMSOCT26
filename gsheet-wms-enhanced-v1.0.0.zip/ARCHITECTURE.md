# G-SHEET WMS - System Architecture

## High-Level Architecture

```
┌─────────────────────────────────────────────────────────────────────────┐
│                         CLIENT LAYER (React)                            │
├─────────────────────────────────────────────────────────────────────────┤
│  Dashboard │ Orders │ Inventory │ Admin │ Profile │ Auth Pages          │
│  (Responsive: Mobile/Tablet/Desktop)                                    │
└──────────────────────────┬──────────────────────────────────────────────┘
                           │ HTTP/HTTPS
┌──────────────────────────▼──────────────────────────────────────────────┐
│                    APPLICATION LAYER (Next.js 16)                       │
├──────────────────────────────────────────────────────────────────────────┤
│  ┌─ Server Components        ┌─ API Routes           ┌─ Server Actions   │
│  │  ├─ page.tsx             │  ├─ /api/auth        │  ├─ orders.ts     │
│  │  ├─ layout.tsx           │  └─ [...all]         │  ├─ inventory.ts  │
│  │  └─ SSR Pages            │                       │  ├─ alerts.ts     │
│  └─                         └─                      │  └─ sheets.ts     │
│  ┌─ Client Components          ┌─ Middleware                            │
│  │  ├─ order-card             │  ├─ Auth checks     └─                │
│  │  ├─ alerts-panel           │  └─ Route guards                        │
│  │  ├─ sync-button            │                                         │
│  │  └─ UI Components          └─                                        │
│  └─                                                                      │
└──────────────────────────┬──────────────────────────────────────────────┘
                           │ TypeScript
┌──────────────────────────▼──────────────────────────────────────────────┐
│                   BUSINESS LOGIC LAYER                                   │
├──────────────────────────────────────────────────────────────────────────┤
│  ┌─ Authentication            ┌─ Authorization       ┌─ Validation      │
│  │  ├─ Better Auth           │  ├─ Role checks      │  ├─ Input checks  │
│  │  ├─ Sessions              │  ├─ User scoping     │  └─ Business rules│
│  │  └─ Email/Password        │  └─ Permission tests │                   │
│  └─                          └─                     └─                  │
│  ┌─ Order Processing          ┌─ Inventory Mgmt     ┌─ Alerts System   │
│  │  ├─ Status workflow        │  ├─ Stock tracking  │  ├─ Alert creation│
│  │  ├─ Assignment             │  ├─ Movement log    │  ├─ Notifications │
│  │  ├─ Timeline tracking      │  └─ Low stock calc  │  └─ Read tracking │
│  │  └─ Item management        │                     │                   │
│  └─                          └─                     └─                  │
│  ┌─ Google Sheets Integration                                            │
│  │  ├─ Pull (Import)          ├─ Push (Export)      ├─ Sync Logging    │
│  │  ├─ Conflict resolution    ├─ Error handling     └─ History tracking│
│  │  └─                        └─                                        │
│  └─                                                                      │
└──────────────────────────┬──────────────────────────────────────────────┘
                           │ Drizzle ORM
┌──────────────────────────▼──────────────────────────────────────────────┐
│                   DATA ACCESS LAYER (Drizzle ORM)                        │
├──────────────────────────────────────────────────────────────────────────┤
│  ┌─ Query Builder            ┌─ Type Safety       ┌─ Relations         │
│  │  ├─ SELECT               │  ├─ TypeScript      │  ├─ user.orders    │
│  │  ├─ INSERT               │  ├─ Validation      │  ├─ order.items    │
│  │  ├─ UPDATE               │  └─ Autocomplete    │  └─ inventory.mvmts│
│  │  └─ DELETE               │                     │                    │
│  └─                         └─                    └─                   │
└──────────────────────────┬──────────────────────────────────────────────┘
                           │ SQL
┌──────────────────────────▼──────────────────────────────────────────────┐
│                    DATABASE LAYER (Neon PostgreSQL)                      │
├──────────────────────────────────────────────────────────────────────────┤
│  User Tables        │ Order Tables         │ Inventory Tables          │
│  ├─ user           │ ├─ orders            │ ├─ inventory              │
│  ├─ session        │ ├─ orderItems        │ ├─ inventoryMovements     │
│  ├─ account        │ └─                   │ └─                        │
│  ├─ verification   │                      │                           │
│  ├─ userRole       │ System Tables        │ Integration Tables        │
│  └─                ├─ alerts              │ ├─ sheetSyncLog           │
│                    └─                     │ └─                        │
└──────────────────────────────────────────────────────────────────────────┘
```

## Data Flow

### Order Processing Flow
```
Staff View Order → Update Status → Server Action
    ↓
[Authorization Check]
    ↓
[Update Database] → Drizzle ORM → PostgreSQL
    ↓
[Trigger Alerts] if status change
    ↓
[Revalidate Cache] for real-time update
    ↓
UI Updates with new status
```

### Google Sheets Sync Flow
```
Admin clicks "Pull from Sheets"
    ↓
[Authenticate with Google API]
    ↓
[Fetch Sheet Data]
    ↓
[Parse Orders/Inventory]
    ↓
[Match/Merge with DB]
    ↓
[Log Sync Result]
    ↓
[Revalidate Dashboard]
    ↓
Sync complete notification
```

## Database Relationships

```
user (1) ─── (N) session
user (1) ─── (N) account
user (1) ─── (1) userRole
user (1) ─── (N) orders (assignedTo)
user (1) ─── (N) inventoryMovements (createdBy)
user (1) ─── (N) inventory (lastUpdatedBy)
user (1) ─── (N) alerts (readBy)

orders (1) ─── (N) orderItems
orderItems (N) ─── (1) inventory (via skuId)

inventory (1) ─── (N) inventoryMovements (via skuId)
```

## Authentication & Authorization Flow

```
User Login
    ↓
[POST /api/auth/sign-in]
    ↓
[Hash password, check DB]
    ↓
[Create Session Token]
    ↓
[Set Secure Cookie]
    ↓
[Redirect to Dashboard]

For Protected Routes:
    ↓
[Check Session Cookie]
    ↓
[Verify Token Signature]
    ↓
[Get User & Role]
    ↓
[Check Permissions]
    ↓
[Allow/Deny Access]
```

## Role-Based Access Control (RBAC)

### Staff Role
- View assigned orders
- Update order status (move between stages)
- View inventory (read-only)
- View alerts
- Edit profile

### Admin Role
- All Staff permissions
- Create/edit orders
- Manage inventory
- Add/remove staff
- Configure Google Sheets sync
- View system settings
- Manage users

## API Endpoints

### Authentication
```
POST   /api/auth/sign-up       - Create account
POST   /api/auth/sign-in       - Login
POST   /api/auth/sign-out      - Logout
GET    /api/auth/session       - Current session
```

### Server Actions (Protected)
```
Orders
  getOrders()
  getOrderById(id)
  updateOrderStatus(id, status)
  assignOrder(id, userId)
  addOrderNote(id, note)

Inventory
  getInventory()
  getInventoryBySku(sku)
  updateInventoryQuantity(sku, change)
  getLowStockItems()
  getInventoryMovements(sku?)

Alerts
  getAlerts()
  getUnreadAlertsCount()
  markAlertAsRead(id)
  markAllAlertsAsRead()
  createAlert(type, severity, title, message)

Google Sheets
  pullFromGoogleSheets()
  pushToGoogleSheets()
  getSyncHistory(limit)
  configureAutoSync(minutes)
```

## Component Hierarchy

```
Layout.tsx (Root)
├─ Header (Logo, Alerts, Profile)
│  ├─ AlertsPanel
│  ├─ ProfileMenu
│  └─ Navigation
├─ Main Content
│  ├─ Dashboard (/)
│  │  ├─ StatsGrid
│  │  ├─ OrdersList
│  │  │  └─ OrderCard (multiple)
│  │  └─ Sidebar
│  │     ├─ LowStockAlert
│  │     ├─ InventorySummary
│  │     └─ RecentActivity
│  ├─ Orders (/orders)
│  │  └─ StatusSections
│  │     └─ OrderCard (multiple)
│  ├─ OrderDetail (/orders/[id])
│  │  ├─ StatusFlow
│  │  ├─ ItemsTable
│  │  └─ CustomerInfo
│  ├─ Inventory (/inventory)
│  │  ├─ StatsGrid
│  │  ├─ LowStockTable
│  │  └─ InventoryTable
│  ├─ AdminUsers (/admin/users)
│  │  ├─ AdminsTable
│  │  └─ StaffTable
│  ├─ AdminSettings (/admin/settings)
│  │  ├─ SheetsConfig
│  │  ├─ SystemConfig
│  │  └─ SyncStatus
│  └─ Auth Pages
│     ├─ SignIn (/sign-in)
│     └─ SignUp (/sign-up)
└─ Footer (optional)
```

## Performance Optimization

### Caching Strategy
```
Level 1: Next.js ISR (Incremental Static Regeneration)
  ├─ Static pages pre-built
  └─ Revalidate on mutations

Level 2: Database Query Caching
  ├─ Server component caching
  └─ RevalidatePath() after updates

Level 3: Client-side State
  ├─ useOptimistic for immediate UI
  └─ SWR for background sync
```

### Database Optimization
```
Indexes
├─ orders.status
├─ orders.assignedTo
├─ inventory.quantity
├─ alerts.readBy
└─ sheetSyncLog.createdAt

Query Optimization
├─ Select specific columns
├─ Use relations for joins
└─ Pagination for large datasets
```

## Security Layers

```
1. Transport Security
   └─ HTTPS/TLS encryption

2. Authentication
   ├─ Better Auth sessions
   ├─ Secure cookies (httpOnly)
   └─ Token signing with BETTER_AUTH_SECRET

3. Authorization
   ├─ Role-based access
   ├─ User scoping on queries
   └─ Server-side permission checks

4. Data Protection
   ├─ SQL parameter binding
   ├─ Input validation
   └─ XSS protection

5. Audit Trail
   ├─ Inventory movements logged
   ├─ Sync history tracked
   └─ User actions timestamped
```

## Deployment Architecture

```
GitHub Repository
       ↓
Vercel CI/CD
├─ Lint & Build
├─ Test
└─ Deploy
       ↓
Edge Network (Vercel CDN)
├─ Static content
└─ API routes
       ↓
Next.js Application Server
├─ Server components
├─ API endpoints
└─ Server actions
       ↓
Neon Database
├─ Connection pooling
├─ Automatic backups
└─ Read replicas
```

## Monitoring & Logging

```
Application Logs
├─ Console output [v0] prefix
├─ Error stack traces
└─ Request/response timing

Database Monitoring
├─ Query performance
├─ Connection pool stats
└─ Slow query logs

User Activity
├─ Login/logout events
├─ Data modifications
└─ Sync operations
```

## Scaling Considerations

### Current Capacity
- Single Neon PostgreSQL instance
- In-memory alerting
- No external job queue

### Future Scaling
1. **Database**: Read replicas for reporting
2. **Caching**: Redis for session/alert cache
3. **Jobs**: Background job queue for sync
4. **Real-time**: WebSocket for live updates
5. **Search**: Elasticsearch for order search
6. **Analytics**: Data warehouse for reporting

This architecture provides a solid foundation for a modern, scalable warehouse management system.
