import { auth } from "@/lib/auth";
import { headers } from "next/headers";
import { redirect } from "next/navigation";
import { getOrders } from "@/app/actions/orders";
import { db } from "@/lib/db";
import { userRole } from "@/lib/db/schema";
import { eq } from "drizzle-orm";
import { OrderCard } from "@/components/order-card";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { AlertsPanel } from "@/components/alerts-panel";

export const metadata = {
  title: "Orders - G-SHEET WMS",
  description: "Order management and tracking",
};

export default async function OrdersPage() {
  const session = await auth.api.getSession({ headers: await headers() });
  if (!session?.user) redirect("/sign-in");

  const userRoleData = await db
    .select()
    .from(userRole)
    .where(eq(userRole.userId, session.user.id));
  const role = userRoleData[0]?.role || "staff";

  const orders = await getOrders();

  const statusGroups = {
    received: orders.filter((o) => o.status === "received"),
    picked: orders.filter((o) => o.status === "picked"),
    packed: orders.filter((o) => o.status === "packed"),
    shipped: orders.filter((o) => o.status === "shipped"),
  };

  return (
    <div className="min-h-screen bg-background">
      <header className="bg-primary text-primary-foreground shadow-md">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold">Orders Management</h1>
            </div>
            <div className="flex items-center gap-4">
              <AlertsPanel />
              <Link href="/">
                <Button variant="secondary" size="sm">
                  Dashboard
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 gap-8">
          {/* Received Orders */}
          <section>
            <h2 className="text-xl font-bold mb-4 text-blue-900">
              📥 Received ({statusGroups.received.length})
            </h2>
            {statusGroups.received.length === 0 ? (
              <p className="text-muted-foreground text-sm">
                No orders received yet
              </p>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {statusGroups.received.map((order) => (
                  <OrderCard key={order.id} order={order} />
                ))}
              </div>
            )}
          </section>

          {/* Picked Orders */}
          <section>
            <h2 className="text-xl font-bold mb-4 text-yellow-900">
              🔍 Picked ({statusGroups.picked.length})
            </h2>
            {statusGroups.picked.length === 0 ? (
              <p className="text-muted-foreground text-sm">
                No orders in picking stage
              </p>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {statusGroups.picked.map((order) => (
                  <OrderCard key={order.id} order={order} />
                ))}
              </div>
            )}
          </section>

          {/* Packed Orders */}
          <section>
            <h2 className="text-xl font-bold mb-4 text-purple-900">
              📦 Packed ({statusGroups.packed.length})
            </h2>
            {statusGroups.packed.length === 0 ? (
              <p className="text-muted-foreground text-sm">
                No orders in packing stage
              </p>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {statusGroups.packed.map((order) => (
                  <OrderCard key={order.id} order={order} />
                ))}
              </div>
            )}
          </section>

          {/* Shipped Orders */}
          <section>
            <h2 className="text-xl font-bold mb-4 text-green-900">
              ✈️ Shipped ({statusGroups.shipped.length})
            </h2>
            {statusGroups.shipped.length === 0 ? (
              <p className="text-muted-foreground text-sm">
                No orders shipped yet
              </p>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {statusGroups.shipped.map((order) => (
                  <OrderCard key={order.id} order={order} />
                ))}
              </div>
            )}
          </section>
        </div>
      </main>
    </div>
  );
}
