"use server";

import { auth } from "@/lib/auth";
import { db } from "@/lib/db";
import {
  orders,
  orderItems,
  inventory,
  sheetSyncLog,
  userRole,
} from "@/lib/db/schema";
import { eq } from "drizzle-orm";
import { headers } from "next/headers";
import { revalidatePath } from "next/cache";
import { v4 as uuidv4 } from "uuid";

// Note: In production, use the Google Sheets API with proper authentication
// For now, this is a template for bi-directional sync

async function getUserId() {
  const session = await auth.api.getSession({ headers: await headers() });
  if (!session?.user) throw new Error("Unauthorized");
  return session.user.id;
}

async function getUserRole(userId: string) {
  const roleData = await db
    .select()
    .from(userRole)
    .where(eq(userRole.userId, userId));
  return roleData[0]?.role || "staff";
}

// PULL from Google Sheets - Import orders and inventory from Sheet
export async function pullFromGoogleSheets() {
  const userId = await getUserId();
  const role = await getUserRole(userId);

  if (role !== "admin") throw new Error("Only admins can sync sheets");

  try {
    // This would connect to Google Sheets API
    // For now, this is a template showing the structure

    const syncLog = {
      id: uuidv4(),
      direction: "pull" as const,
      status: "success" as const,
      recordsProcessed: 0,
      errorMessage: null,
    };

    // In production, you would:
    // 1. Authenticate with Google Sheets API
    // 2. Fetch data from the sheet using credentials
    // 3. Parse orders and inventory data
    // 4. Match with existing records or create new ones
    // 5. Update status timestamps

    const SHEET_ID = process.env.GOOGLE_SHEETS_ID;
    const RANGE = "Sheet1!A1:Z1000";

    if (!SHEET_ID) {
      throw new Error("Google Sheets ID not configured");
    }

    // Placeholder for API call
    console.log("[v0] Pulling from Google Sheet:", SHEET_ID);

    await db.insert(sheetSyncLog).values(syncLog);
    revalidatePath("/");

    return {
      success: true,
      message: `Synced data from Google Sheets`,
      recordsProcessed: syncLog.recordsProcessed,
    };
  } catch (error) {
    const errorMessage =
      error instanceof Error ? error.message : "Unknown error";

    await db.insert(sheetSyncLog).values({
      id: uuidv4(),
      direction: "pull",
      status: "failed",
      recordsProcessed: 0,
      errorMessage,
    });

    throw error;
  }
}

// PUSH to Google Sheets - Export orders and inventory to Sheet
export async function pushToGoogleSheets() {
  const userId = await getUserId();
  const role = await getUserRole(userId);

  if (role !== "admin") throw new Error("Only admins can sync sheets");

  try {
    const [ordersList, inventoryList] = await Promise.all([
      db.query.orders.findMany({
        with: { items: true },
      }),
      db.query.inventory.findMany(),
    ]);

    // Format data for Google Sheets
    const ordersData = ordersList.map((order) => [
      order.orderNumber,
      order.status,
      order.customerName || "",
      order.customerPhone || "",
      order.totalItems,
      order.createdAt?.toISOString() || "",
      order.notes || "",
    ]);

    const inventoryData = inventoryList.map((item) => [
      item.skuId,
      item.productName,
      item.quantity,
      item.minimumLevel,
      item.location || "",
    ]);

    // In production, use Google Sheets API to write data
    console.log("[v0] Pushing to Google Sheets");
    console.log("Orders to push:", ordersData.length);
    console.log("Inventory items to push:", inventoryData.length);

    const syncLog = {
      id: uuidv4(),
      direction: "push" as const,
      status: "success" as const,
      recordsProcessed: ordersData.length + inventoryData.length,
      errorMessage: null,
    };

    await db.insert(sheetSyncLog).values(syncLog);
    revalidatePath("/");

    return {
      success: true,
      message: `Pushed ${ordersData.length + inventoryData.length} records to Google Sheets`,
      recordsProcessed: syncLog.recordsProcessed,
    };
  } catch (error) {
    const errorMessage =
      error instanceof Error ? error.message : "Unknown error";

    await db.insert(sheetSyncLog).values({
      id: uuidv4(),
      direction: "push",
      status: "failed",
      recordsProcessed: 0,
      errorMessage,
    });

    throw error;
  }
}

// Get sync history
export async function getSyncHistory(limit = 20) {
  const userId = await getUserId();
  const role = await getUserRole(userId);

  if (role !== "admin") throw new Error("Only admins can view sync history");

  return db.query.sheetSyncLog.findMany({
    orderBy: (log) => [log.createdAt],
    limit,
  });
}

// Configure automatic sync (run every N minutes)
export async function configureAutoSync(intervalMinutes: number = 5) {
  const userId = await getUserId();
  const role = await getUserRole(userId);

  if (role !== "admin") throw new Error("Only admins can configure sync");

  // Store auto-sync configuration in environment or database
  // This would typically be stored in a settings table
  console.log(`[v0] Auto-sync configured for every ${intervalMinutes} minutes`);

  revalidatePath("/");

  return {
    success: true,
    message: `Auto-sync configured for every ${intervalMinutes} minutes`,
  };
}
