'use client'

import { useState, useOptimistic, useTransition } from 'react'
import { Button } from '@/components/ui/button'
import { updateOrderStatus } from '@/app/actions/orders'
import Link from 'next/link'
import { Loader2 } from 'lucide-react'

const statusColors: Record<string, string> = {
  received: 'bg-blue-50 border-blue-200 text-blue-900',
  picked: 'bg-yellow-50 border-yellow-200 text-yellow-900',
  packed: 'bg-purple-50 border-purple-200 text-purple-900',
  shipped: 'bg-green-50 border-green-200 text-green-900',
}

const statusBadges: Record<string, string> = {
  received: 'bg-blue-100 text-blue-800',
  picked: 'bg-yellow-100 text-yellow-800',
  packed: 'bg-purple-100 text-purple-800',
  shipped: 'bg-green-100 text-green-800',
}

const nextStatus: Record<string, string> = {
  received: 'picked',
  picked: 'packed',
  packed: 'shipped',
  shipped: 'shipped',
}

type Order = {
  id: string
  orderNumber: string
  status: string
  customerName: string | null
  totalItems: number | null
  createdAt: Date | string
  assignedUser?: { name: string | null; email: string } | null
}

export function OrderCardOptimistic({
  order,
}: {
  order: Order
}) {
  const [isPending, startTransition] = useTransition()
  const [optimisticStatus, setOptimisticStatus] = useOptimistic(
    order.status,
    (_, newStatus: string) => newStatus
  )

  const statusFlow = ['received', 'picked', 'packed', 'shipped']
  const currentIndex = statusFlow.indexOf(optimisticStatus)
  const isComplete = currentIndex === statusFlow.length - 1

  const handleStatusChange = (newStatus: string) => {
    startTransition(async () => {
      setOptimisticStatus(newStatus)
      try {
        await updateOrderStatus(order.id, newStatus)
      } catch (error) {
        console.error('Failed to update order status', error)
        // Revert optimistic update on error
        setOptimisticStatus(order.status)
      }
    })
  }

  return (
    <Link href={`/orders/${order.id}`}>
      <div
        className={`border rounded-lg p-4 cursor-pointer transition-all hover:shadow-md active:scale-[0.98] touch-manipulation ${
          statusColors[optimisticStatus] || 'bg-gray-50 border-gray-200'
        }`}
      >
        <div className="flex items-start justify-between mb-3">
          <div>
            <h3 className="font-semibold text-lg">{order.orderNumber}</h3>
            <p className="text-sm opacity-75">{order.customerName}</p>
          </div>
          <span
            className={`px-2 py-1 rounded text-xs font-medium ${statusBadges[optimisticStatus]}`}
          >
            {optimisticStatus.toUpperCase()}
          </span>
        </div>

        <div className="flex items-center justify-between text-sm mb-3">
          <span>Items: {order.totalItems}</span>
          <span className="text-xs opacity-50">
            {new Date(order.createdAt).toLocaleDateString()}
          </span>
        </div>

        {order.assignedUser && (
          <div className="text-xs opacity-75 mb-3">
            Assigned to: {order.assignedUser.name || order.assignedUser.email}
          </div>
        )}

        {!isComplete && (
          <Button
            size="sm"
            onClick={(e) => {
              e.preventDefault()
              handleStatusChange(nextStatus[optimisticStatus])
            }}
            disabled={isPending}
            className="w-full min-h-[44px] touch-manipulation"
            variant="outline"
          >
            {isPending ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                Updating...
              </>
            ) : (
              `Move to ${nextStatus[optimisticStatus]}`
            )}
          </Button>
        )}
      </div>
    </Link>
  )
}
