"use client";

import { Button } from "@/components/ui/button";
import { updateOrderStatus } from "@/app/actions/orders";
import { useState } from "react";
import Link from "next/link";

const statusColors: Record<string, string> = {
  received: "bg-blue-50 border-blue-200 text-blue-900",
  picked: "bg-yellow-50 border-yellow-200 text-yellow-900",
  packed: "bg-purple-50 border-purple-200 text-purple-900",
  shipped: "bg-green-50 border-green-200 text-green-900",
};

const statusBadges: Record<string, string> = {
  received: "bg-blue-100 text-blue-800",
  picked: "bg-yellow-100 text-yellow-800",
  packed: "bg-purple-100 text-purple-800",
  shipped: "bg-green-100 text-green-800",
};

export function OrderCard({
  order,
  onStatusChange,
}: {
  order: any;
  onStatusChange?: () => void;
}) {
  const [isUpdating, setIsUpdating] = useState(false);

  const handleStatusChange = async (newStatus: string) => {
    setIsUpdating(true);
    try {
      await updateOrderStatus(order.id, newStatus);
      onStatusChange?.();
    } catch (error) {
      console.error("Failed to update order status", error);
    } finally {
      setIsUpdating(false);
    }
  };

  const nextStatus: Record<string, string> = {
    received: "picked",
    picked: "packed",
    packed: "shipped",
    shipped: "shipped",
  };

  const statusFlow = ["received", "picked", "packed", "shipped"];
  const currentIndex = statusFlow.indexOf(order.status);

  return (
    <Link href={`/orders/${order.id}`}>
      <div
        className={`border rounded-lg p-4 cursor-pointer transition-all hover:shadow-md ${statusColors[order.status] || "bg-gray-50 border-gray-200"}`}
      >
        <div className="flex items-start justify-between mb-3">
          <div>
            <h3 className="font-semibold text-lg">{order.orderNumber}</h3>
            <p className="text-sm opacity-75">{order.customerName}</p>
          </div>
          <span className={`px-2 py-1 rounded text-xs font-medium ${statusBadges[order.status]}`}>
            {order.status.toUpperCase()}
          </span>
        </div>

        <div className="flex items-center justify-between text-sm mb-3">
          <span>Items: {order.totalItems}</span>
          <span className="text-xs opacity-50">
            {new Date(order.createdAt).toLocaleDateString()}
          </span>
        </div>

        {order.assignedUser && (
          <div className="text-xs opacity-75 mb-3">
            Assigned to: {order.assignedUser.name || order.assignedUser.email}
          </div>
        )}

        {currentIndex < statusFlow.length - 1 && (
          <Button
            size="sm"
            onClick={(e) => {
              e.preventDefault();
              handleStatusChange(nextStatus[order.status]);
            }}
            disabled={isUpdating}
            className="w-full"
            variant="outline"
          >
            {isUpdating ? "Updating..." : `Move to ${nextStatus[order.status]}`}
          </Button>
        )}
      </div>
    </Link>
  );
}
