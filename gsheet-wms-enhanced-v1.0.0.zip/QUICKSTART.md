# G-SHEET WMS - Quick Start Guide

## 5-Minute Setup

### Step 1: Install Dependencies
```bash
cd /vercel/share/v0-project
pnpm install
```

### Step 2: Set Environment Variables
Create `.env.local`:
```
DATABASE_URL=postgresql://user:password@host:5432/database
BETTER_AUTH_SECRET=your-32-char-random-string-here
BETTER_AUTH_URL=http://localhost:3000
```

Generate a secure secret:
```bash
openssl rand -base64 32
```

### Step 3: Run Development Server
```bash
pnpm dev
```

### Step 4: Access the Application
Open browser: http://localhost:3000

## First Login

### Create Admin Account
1. Click "Sign Up"
2. Enter email and password
3. Confirm email (auto-verified in dev)
4. You're logged in as an admin

### Create Staff Account
1. Sign out
2. Sign up with different email
3. Admin promotes to staff (in users page)

## Test the Features

### 1. View Dashboard
- Check order statistics
- View alerts
- See low stock items

### 2. Manage Orders
- Navigate to `/orders`
- View orders grouped by status
- Click an order for details
- Update order status

### 3. Manage Inventory
- Go to `/inventory` (admin only)
- View all SKUs
- See low stock alerts
- Check movement history

### 4. Admin Controls
- Users: `/admin/users` - Manage staff
- Settings: `/admin/settings` - Configure sync

### 5. Alerts
- Click bell icon in header
- View recent alerts
- Dismiss alerts

## Add Sample Data

### Create Orders via Server Action
```typescript
// In your database editor or through API:
INSERT INTO orders (id, orderNumber, status, customerName, totalItems)
VALUES 
  ('1', 'ORD-001', 'received', 'John Doe', 5),
  ('2', 'ORD-002', 'picked', 'Jane Smith', 3),
  ('3', 'ORD-003', 'packed', 'Bob Johnson', 2);
```

### Add Inventory
```typescript
INSERT INTO inventory (id, skuId, productName, quantity, minimumLevel)
VALUES 
  ('1', 'SKU-A001', 'Widget Red', 50, 10),
  ('2', 'SKU-A002', 'Widget Blue', 5, 10),
  ('3', 'SKU-B001', 'Gadget Silver', 25, 5);
```

## Key Pages

| URL | Purpose | Role |
|-----|---------|------|
| `/` | Main dashboard | All |
| `/orders` | Order list | All |
| `/orders/[id]` | Order details | All |
| `/inventory` | Inventory mgmt | Admin |
| `/admin/users` | User management | Admin |
| `/admin/settings` | System config | Admin |
| `/profile` | User profile | All |

## Common Tasks

### Update Order Status
1. Go to `/orders`
2. Click an order card
3. Click "Move to [next-status]"
4. Status updates automatically

### Add Inventory
1. Go to `/inventory`
2. Would need to add UI for new items (currently displays existing)
3. Use database directly to add new SKUs

### Create User
1. Sign up as new user
2. Admin promotes to staff via `/admin/users`

### Configure Google Sheets
1. Go to `/admin/settings`
2. Set `GOOGLE_SHEETS_ID` environment variable
3. Use "Pull" or "Push" buttons to sync

## API Testing

### Sign Up
```bash
curl -X POST http://localhost:3000/api/auth/sign-up \
  -H "Content-Type: application/json" \
  -d '{"email":"user@example.com","password":"password","name":"User"}'
```

### Sign In
```bash
curl -X POST http://localhost:3000/api/auth/sign-in \
  -H "Content-Type: application/json" \
  -d '{"email":"user@example.com","password":"password"}'
```

## Troubleshooting

### Port 3000 Already in Use
```bash
# Kill process on port 3000
lsof -ti:3000 | xargs kill -9
# Or use different port
pnpm dev -p 3001
```

### Database Connection Error
- Check DATABASE_URL format
- Verify Neon credentials
- Test connection: `psql $DATABASE_URL`

### Auth Not Working
- Generate new BETTER_AUTH_SECRET
- Clear browser cookies
- Check console for errors

### Styling Issues
- Clear Next.js cache: `rm -rf .next`
- Rebuild: `pnpm dev`

## Next Steps

1. **Configure Google Sheets**: Get API credentials and set environment variable
2. **Add Products**: Populate inventory with your SKUs
3. **Create Orders**: Import from Google Sheets or add manually
4. **Assign Staff**: Add warehouse team members
5. **Set Thresholds**: Configure low stock alerts
6. **Test Sync**: Try bi-directional Google Sheets sync

## Resources

- Full Documentation: See `README.md`
- Implementation Details: See `IMPLEMENTATION_SUMMARY.md`
- API Reference: Check code in `/app/actions/`

## Support

For issues:
1. Check console logs (look for [v0] prefix)
2. Review error messages
3. Verify environment variables
4. Check database connectivity

## Production Deployment

### Pre-deployment Checklist
- [ ] Generate secure BETTER_AUTH_SECRET
- [ ] Set production DATABASE_URL
- [ ] Configure Google Sheets ID
- [ ] Test all features
- [ ] Review security settings
- [ ] Set up monitoring/logging

### Deploy to Vercel
```bash
vercel deploy
```

Set environment variables in Vercel dashboard under project settings.

Enjoy your Warehouse Management System!
