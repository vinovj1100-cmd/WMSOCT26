import { auth } from "@/lib/auth";
import { headers } from "next/headers";
import { redirect } from "next/navigation";
import AuthForm from "@/components/auth-form";

export const metadata = {
  title: "Sign In - G-SHEET WMS",
  description: "Sign in to the warehouse management system",
};

export default async function SignInPage() {
  const session = await auth.api.getSession({ headers: await headers() });
  if (session?.user) redirect("/");

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        <div className="bg-white rounded-lg shadow-lg p-8">
          <div className="text-center mb-8">
            <h1 className="text-3xl font-bold text-gray-900">G-SHEET WMS</h1>
            <p className="text-gray-600 mt-2">Warehouse Management System</p>
          </div>
          <AuthForm mode="sign-in" />
        </div>
      </div>
    </div>
  );
}
