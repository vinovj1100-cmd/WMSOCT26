# 🚀 Deployment Guide - G-SHEET WMS

This guide covers **free, stable, long-term deployment options** for the Warehouse Management System.

---

## 📋 Prerequisites

1. **GitHub Account** - To host your code
2. **Database** - Free PostgreSQL from Neon (recommended)
3. **Deployment Platform** - Choose one from the options below

---

## 🗄️ Step 1: Setup Database (Neon - Free Tier)

**Why Neon?**
- ✅ Free tier: 0.5 GB storage, 1 database
- ✅ Serverless PostgreSQL (scales to zero)
- ✅ No credit card required
- ✅ Excellent for Next.js apps
- ✅ Automatic backups

### Setup Steps:

1. Go to [neon.tech](https://neon.tech) and sign up
2. Create a new project
3. Copy the connection string (looks like):
   ```
   postgresql://user:password@host.neon.tech/dbname?sslmode=require
   ```
4. Save this as `DATABASE_URL`

### Run Database Migrations:

The schema will be created automatically on first run, or manually:

```bash
# Install dependencies
pnpm install

# Push schema to database
pnpm exec drizzle-kit push:pg
```

---

## 🎯 Deployment Options (Ranked by Ease & Stability)

### Option 1: 🥇 Vercel (Easiest - Recommended for Beginners)

**Pros:**
- ✅ Zero configuration
- ✅ Automatic HTTPS
- ✅ Global CDN
- ✅ Free tier: Generous limits
- ✅ Auto-deploy on git push
- ✅ Built-in analytics

**Cons:**
- ⚠️ Serverless functions (10s timeout on free tier)
- ⚠️ Cold starts possible

**Setup:**

1. Push your code to GitHub
2. Go to [vercel.com](https://vercel.com) and sign in with GitHub
3. Click "Import Project" → Select your repository
4. Add environment variables:
   ```
   DATABASE_URL=your-neon-connection-string
   BETTER_AUTH_SECRET=your-random-32-char-secret
   BETTER_AUTH_URL=https://your-app.vercel.app
   GOOGLE_SHEETS_ID=your-sheet-id (optional)
   ```
5. Click "Deploy"
6. Done! Your app is live at `https://your-app.vercel.app`

**Auto-deployments:** Every push to `main` branch triggers a new deployment.

---

### Option 2: 🥈 Railway (Best for Docker/Traditional Hosting)

**Pros:**
- ✅ Free tier: $5 credit/month (enough for small apps)
- ✅ Docker support
- ✅ No cold starts
- ✅ Easy environment variable management
- ✅ Built-in metrics and logs

**Cons:**
- ⚠️ Requires credit card for verification (not charged on free tier)
- ⚠️ Limited to $5/month usage

**Setup:**

1. Install Railway CLI:
   ```bash
   npm i -g @railway/cli
   ```

2. Login and initialize:
   ```bash
   railway login
   railway init
   ```

3. Add environment variables:
   ```bash
   railway variables set DATABASE_URL="your-neon-url"
   railway variables set BETTER_AUTH_SECRET="your-secret"
   railway variables set BETTER_AUTH_URL="https://your-app.up.railway.app"
   ```

4. Deploy:
   ```bash
   railway up
   ```

5. Or connect GitHub for auto-deployments:
   - Go to [railway.app](https://railway.app)
   - New Project → Deploy from GitHub
   - Select your repo
   - Railway auto-detects the Dockerfile
   - Add environment variables in dashboard

**Cost:** Free $5/month credit is enough for a small WMS app (~500 hours runtime).

---

### Option 3: 🥉 Render (Best Free Tier - No Credit Card)

**Pros:**
- ✅ Free tier: 750 hours/month
- ✅ No credit card required
- ✅ Docker support
- ✅ Auto-deploy from GitHub
- ✅ Free SSL

**Cons:**
- ⚠️ Spins down after 15 min of inactivity (cold start ~30s)
- ⚠️ 512 MB RAM limit

**Setup:**

1. Push code to GitHub
2. Go to [render.com](https://render.com) and sign up
3. New → Web Service
4. Connect your GitHub repo
5. Render auto-detects `render.yaml`
6. Add environment variables:
   - `DATABASE_URL`
   - `BETTER_AUTH_SECRET` (auto-generate)
   - `BETTER_AUTH_URL` (your Render URL)
7. Click "Create Web Service"

**Keep it warm (optional):**
Use a service like [UptimeRobot](https://uptimerobot.com) to ping `/api/health` every 5 minutes.

---

### Option 4: 🐳 Fly.io (Best for Global Distribution)

**Pros:**
- ✅ Free tier: 3 shared-cpu VMs, 3GB storage
- ✅ Global edge deployment
- ✅ Docker native
- ✅ No cold starts with min_machines_running=1

**Cons:**
- ⚠️ Requires credit card
- ⚠️ Slightly more complex CLI

**Setup:**

1. Install Fly CLI:
   ```bash
   # Windows (PowerShell)
   iwr https://fly.io/install.ps1 -useb | iex
   
   # macOS/Linux
   curl -L https://fly.io/install.sh | sh
   ```

2. Login and launch:
   ```bash
   fly auth login
   fly launch
   ```

3. Set secrets:
   ```bash
   fly secrets set DATABASE_URL="your-neon-url"
   fly secrets set BETTER_AUTH_SECRET="your-secret"
   fly secrets set BETTER_AUTH_URL="https://your-app.fly.dev"
   ```

4. Deploy:
   ```bash
   fly deploy
   ```

---

## 🔐 Environment Variables Reference

| Variable | Required | Description | Example |
|----------|----------|-------------|---------|
| `DATABASE_URL` | ✅ | PostgreSQL connection string | `postgresql://user:pass@host/db` |
| `BETTER_AUTH_SECRET` | ✅ | Random 32+ character string | Generate: `openssl rand -base64 32` |
| `BETTER_AUTH_URL` | ✅ | Your app's public URL | `https://your-app.com` |
| `GOOGLE_SHEETS_ID` | ❌ | Google Sheets ID for sync | From sheet URL |
| `NODE_ENV` | ✅ | Environment | `production` |

---

## 🔄 CI/CD Setup (GitHub Actions)

The included `.github/workflows/ci-cd.yml` provides:
- ✅ Lint and type checking
- ✅ Build verification
- ✅ Docker image building
- ✅ Deployment placeholder

### To enable deployments:

1. Add secrets to GitHub repo:
   - Settings → Secrets and variables → Actions
   - Add: `DATABASE_URL`, `BETTER_AUTH_SECRET`, `BETTER_AUTH_URL`

2. Uncomment platform-specific deployment steps in `ci-cd.yml`

---

## 📊 Monitoring & Health Checks

### Health Check Endpoint

All platforms can monitor: `https://your-app.com/api/health`

Response:
```json
{
  "status": "healthy",
  "timestamp": "2024-01-01T00:00:00.000Z",
  "checks": {
    "database": { "status": "up", "latencyMs": 45 },
    "server": { "status": "up", "uptime": 3600 }
  }
}
```

### Recommended Monitoring (Free):

1. **UptimeRobot** - Ping `/api/health` every 5 minutes
2. **Better Uptime** - Advanced monitoring with alerts
3. **Sentry** - Error tracking (free tier available)

---

## 🔧 Post-Deployment Checklist

- [ ] Test sign-up and sign-in
- [ ] Create first admin user
- [ ] Test order creation and status updates
- [ ] Test inventory management
- [ ] Verify health check: `/api/health`
- [ ] Test on mobile device
- [ ] Install PWA on phone (Add to Home Screen)
- [ ] Set up monitoring/alerts
- [ ] Configure Google Sheets sync (if using)
- [ ] Test offline functionality (PWA)

---

## 🐛 Troubleshooting

### Database Connection Issues

```bash
# Test connection locally
pnpm exec drizzle-kit push:pg
```

### Build Failures

```bash
# Clear Next.js cache
rm -rf .next

# Reinstall dependencies
rm -rf node_modules pnpm-lock.yaml
pnpm install

# Rebuild
pnpm build
```

### Auth Issues

- Ensure `BETTER_AUTH_SECRET` is at least 32 characters
- Verify `BETTER_AUTH_URL` matches your deployment URL
- Check cookies are enabled in browser

### Cold Start Issues (Render)

- Use UptimeRobot to keep app warm
- Or upgrade to paid tier ($7/month) for always-on

---

## 💰 Cost Comparison (Free Tiers)

| Platform | RAM | Storage | Bandwidth | Uptime | Credit Card |
|----------|-----|---------|-----------|--------|-------------|
| **Vercel** | Serverless | 100 GB | 100 GB | 99.99% | ❌ No |
| **Railway** | 512 MB | 1 GB | $5 credit | 99.9% | ✅ Yes* |
| **Render** | 512 MB | 1 GB | 100 GB | Sleeps after 15min | ❌ No |
| **Fly.io** | 256 MB | 3 GB | 160 GB | 99.9% | ✅ Yes* |

*Not charged on free tier, just for verification

---

## 🎯 Recommended Setup for Production

**For Small Teams (1-10 users):**
- **Frontend + Backend:** Vercel (free)
- **Database:** Neon (free)
- **Monitoring:** UptimeRobot (free)
- **Total Cost:** $0/month

**For Medium Teams (10-50 users):**
- **Frontend + Backend:** Railway ($5-10/month)
- **Database:** Neon (free or $19/month for more storage)
- **Monitoring:** Better Uptime ($10/month)
- **Total Cost:** ~$15-40/month

---

## 📱 PWA Installation

After deployment, users can install the app on their devices:

**Android:**
1. Open app in Chrome
2. Tap menu (⋮) → "Add to Home Screen"
3. App icon appears on home screen

**iOS:**
1. Open app in Safari
2. Tap Share → "Add to Home Screen"
3. App icon appears on home screen

**Desktop:**
1. Open app in Chrome/Edge
2. Click install icon in address bar
3. App opens in standalone window

---

## 🔒 Security Checklist

- [ ] HTTPS enabled (automatic on all platforms)
- [ ] Environment variables secured (never commit `.env.local`)
- [ ] Database uses SSL (`?sslmode=require` in connection string)
- [ ] Strong `BETTER_AUTH_SECRET` (32+ random characters)
- [ ] Rate limiting enabled (Better Auth built-in)
- [ ] Security headers configured (already in `next.config.mjs`)
- [ ] Regular dependency updates (`pnpm update`)

---

## 📞 Support

- **Next.js Docs:** https://nextjs.org/docs
- **Neon Docs:** https://neon.tech/docs
- **Vercel Support:** https://vercel.com/support
- **Railway Docs:** https://docs.railway.app
- **Render Docs:** https://render.com/docs
- **Fly.io Docs:** https://fly.io/docs

---

**Last Updated:** January 2024
