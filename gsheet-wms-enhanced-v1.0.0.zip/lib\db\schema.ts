import {
  boolean,
  text,
  timestamp,
  pgTable,
  integer,
} from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";

// Better Auth Tables
export const user = pgTable("user", {
  id: text("id").primaryKey(),
  email: text("email").notNull().unique(),
  emailVerified: boolean("emailVerified").notNull(),
  name: text("name"),
  image: text("image"),
  createdAt: timestamp("createdAt", { withTimezone: true })
    .notNull()
    .defaultNow(),
  updatedAt: timestamp("updatedAt", { withTimezone: true })
    .notNull()
    .defaultNow(),
});

export const session = pgTable("session", {
  id: text("id").primaryKey(),
  expiresAt: timestamp("expiresAt", { withTimezone: true }).notNull(),
  token: text("token").notNull().unique(),
  createdAt: timestamp("createdAt", { withTimezone: true })
    .notNull()
    .defaultNow(),
  updatedAt: timestamp("updatedAt", { withTimezone: true })
    .notNull()
    .defaultNow(),
  ipAddress: text("ipAddress"),
  userAgent: text("userAgent"),
  userId: text("userId")
    .notNull()
    .references(() => user.id, { onDelete: "cascade" }),
});

export const account = pgTable("account", {
  id: text("id").primaryKey(),
  accountId: text("accountId").notNull(),
  providerId: text("providerId").notNull(),
  userId: text("userId")
    .notNull()
    .references(() => user.id, { onDelete: "cascade" }),
  accessToken: text("accessToken"),
  refreshToken: text("refreshToken"),
  idToken: text("idToken"),
  accessTokenExpiresAt: timestamp("accessTokenExpiresAt", {
    withTimezone: true,
  }),
  refreshTokenExpiresAt: timestamp("refreshTokenExpiresAt", {
    withTimezone: true,
  }),
  scope: text("scope"),
  password: text("password"),
  createdAt: timestamp("createdAt", { withTimezone: true })
    .notNull()
    .defaultNow(),
  updatedAt: timestamp("updatedAt", { withTimezone: true })
    .notNull()
    .defaultNow(),
});

export const verification = pgTable("verification", {
  id: text("id").primaryKey(),
  identifier: text("identifier").notNull(),
  value: text("value").notNull(),
  expiresAt: timestamp("expiresAt", { withTimezone: true }).notNull(),
  createdAt: timestamp("createdAt", { withTimezone: true }).defaultNow(),
  updatedAt: timestamp("updatedAt", { withTimezone: true }).defaultNow(),
});

// WMS Tables
export const userRole = pgTable("userRole", {
  id: text("id").primaryKey(),
  userId: text("userId")
    .notNull()
    .unique()
    .references(() => user.id, { onDelete: "cascade" }),
  role: text("role").notNull().default("staff"), // "staff" or "admin"
  createdAt: timestamp("createdAt", { withTimezone: true })
    .notNull()
    .defaultNow(),
});

export const orders = pgTable("orders", {
  id: text("id").primaryKey(),
  orderNumber: text("orderNumber").notNull().unique(),
  status: text("status").notNull().default("received"), // received, picked, packed, shipped
  assignedTo: text("assignedTo").references(() => user.id, {
    onDelete: "set null",
  }),
  sheetId: text("sheetId").unique(),
  customerName: text("customerName"),
  customerPhone: text("customerPhone"),
  totalItems: integer("totalItems").default(0),
  notes: text("notes"),
  createdAt: timestamp("createdAt", { withTimezone: true })
    .notNull()
    .defaultNow(),
  updatedAt: timestamp("updatedAt", { withTimezone: true })
    .notNull()
    .defaultNow(),
  receivedAt: timestamp("receivedAt", { withTimezone: true }),
  pickedAt: timestamp("pickedAt", { withTimezone: true }),
  packedAt: timestamp("packedAt", { withTimezone: true }),
  shippedAt: timestamp("shippedAt", { withTimezone: true }),
});

export const orderItems = pgTable("orderItems", {
  id: text("id").primaryKey(),
  orderId: text("orderId")
    .notNull()
    .references(() => orders.id, { onDelete: "cascade" }),
  skuId: text("skuId").notNull(),
  quantity: integer("quantity").notNull(),
  pickedQuantity: integer("pickedQuantity").default(0),
  status: text("status").notNull().default("pending"), // pending, picked, packed
  createdAt: timestamp("createdAt", { withTimezone: true })
    .notNull()
    .defaultNow(),
  updatedAt: timestamp("updatedAt", { withTimezone: true })
    .notNull()
    .defaultNow(),
});

export const inventory = pgTable("inventory", {
  id: text("id").primaryKey(),
  skuId: text("skuId").notNull().unique(),
  productName: text("productName").notNull(),
  quantity: integer("quantity").notNull().default(0),
  minimumLevel: integer("minimumLevel").notNull().default(10),
  location: text("location"),
  lastUpdatedBy: text("lastUpdatedBy").references(() => user.id, {
    onDelete: "set null",
  }),
  createdAt: timestamp("createdAt", { withTimezone: true })
    .notNull()
    .defaultNow(),
  updatedAt: timestamp("updatedAt", { withTimezone: true })
    .notNull()
    .defaultNow(),
});

export const inventoryMovements = pgTable("inventoryMovements", {
  id: text("id").primaryKey(),
  skuId: text("skuId")
    .notNull()
    .references(() => inventory.skuId, { onDelete: "cascade" }),
  type: text("type").notNull(), // "stock_in", "picked", "adjustment"
  quantity: integer("quantity").notNull(),
  reference: text("reference"),
  createdBy: text("createdBy").references(() => user.id, {
    onDelete: "set null",
  }),
  createdAt: timestamp("createdAt", { withTimezone: true })
    .notNull()
    .defaultNow(),
});

export const alerts = pgTable("alerts", {
  id: text("id").primaryKey(),
  type: text("type").notNull(), // "low_stock", "order_delay", "error", "qc_issue"
  severity: text("severity").notNull().default("info"), // "info", "warning", "error"
  title: text("title").notNull(),
  message: text("message").notNull(),
  relatedId: text("relatedId"),
  readBy: text("readBy").references(() => user.id, { onDelete: "cascade" }),
  readAt: timestamp("readAt", { withTimezone: true }),
  createdAt: timestamp("createdAt", { withTimezone: true })
    .notNull()
    .defaultNow(),
});

export const sheetSyncLog = pgTable("sheetSyncLog", {
  id: text("id").primaryKey(),
  direction: text("direction").notNull(), // "pull" or "push"
  status: text("status").notNull(), // "success" or "failed"
  recordsProcessed: integer("recordsProcessed"),
  errorMessage: text("errorMessage"),
  createdAt: timestamp("createdAt", { withTimezone: true })
    .notNull()
    .defaultNow(),
});

// Relations
export const userRelations = relations(user, ({ one, many }) => ({
  role: one(userRole, {
    fields: [user.id],
    references: [userRole.userId],
  }),
  ordersAssigned: many(orders),
}));

export const ordersRelations = relations(orders, ({ one, many }) => ({
  items: many(orderItems),
  assignedUser: one(user, {
    fields: [orders.assignedTo],
    references: [user.id],
  }),
}));

export const orderItemsRelations = relations(orderItems, ({ one }) => ({
  order: one(orders, {
    fields: [orderItems.orderId],
    references: [orders.id],
  }),
}));

export const inventoryRelations = relations(inventory, ({ many, one }) => ({
  movements: many(inventoryMovements),
  lastUpdatedUser: one(user, {
    fields: [inventory.lastUpdatedBy],
    references: [user.id],
  }),
}));

export const inventoryMovementsRelations = relations(
  inventoryMovements,
  ({ one }) => ({
    inventory: one(inventory, {
      fields: [inventoryMovements.skuId],
      references: [inventory.skuId],
    }),
    createdByUser: one(user, {
      fields: [inventoryMovements.createdBy],
      references: [user.id],
    }),
  })
);
