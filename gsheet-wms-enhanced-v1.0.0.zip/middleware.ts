import { NextResponse } from 'next/server'
import type { NextRequest } from 'next/server'

// Paths that don't require authentication
const publicPaths = ['/sign-in', '/sign-up', '/api/auth', '/manifest.json', '/sw.js', '/icons']

// Paths that require admin role
const adminPaths = ['/admin', '/inventory']

export function middleware(request: NextRequest) {
  const { pathname } = request.nextUrl
  
  // Allow public paths
  if (publicPaths.some(path => pathname.startsWith(path))) {
    return NextResponse.next()
  }

  // Check for session cookie
  const sessionCookie = request.cookies.get('better-auth.session_token')
  
  // Redirect to sign-in if no session
  if (!sessionCookie) {
    const signInUrl = new URL('/sign-in', request.url)
    signInUrl.searchParams.set('callbackUrl', pathname)
    return NextResponse.redirect(signInUrl)
  }

  // For admin paths, we'll do a lightweight check
  // The actual role verification happens in the page (since middleware can't access DB)
  // This just ensures the user is authenticated before reaching admin pages
  if (adminPaths.some(path => pathname.startsWith(path))) {
    // Add a header to indicate this is an admin route
    // The page component will verify the actual role
    const response = NextResponse.next()
    response.headers.set('x-admin-route', 'true')
    return response
  }

  return NextResponse.next()
}

export const config = {
  matcher: [
    /*
     * Match all request paths except:
     * - _next/static (static files)
     * - _next/image (image optimization files)
     * - favicon.ico (favicon file)
     * - public folder files
     */
    '/((?!_next/static|_next/image|favicon.ico|.*\\.(?:svg|png|jpg|jpeg|gif|webp)$).*)',
  ],
}
