"use server";

import { auth } from "@/lib/auth";
import { db } from "@/lib/db";
import { alerts, userRole } from "@/lib/db/schema";
import { eq, desc, isNull } from "drizzle-orm";
import { headers } from "next/headers";
import { revalidatePath } from "next/cache";

async function getUserId() {
  const session = await auth.api.getSession({ headers: await headers() });
  if (!session?.user) throw new Error("Unauthorized");
  return session.user.id;
}

async function getUserRole(userId: string) {
  const roleData = await db
    .select()
    .from(userRole)
    .where(eq(userRole.userId, userId));
  return roleData[0]?.role || "staff";
}

export async function getAlerts() {
  const userId = await getUserId();
  const role = await getUserRole(userId);

  if (role === "admin") {
    return db.query.alerts.findMany({
      orderBy: [desc(alerts.createdAt)],
      limit: 100,
    });
  }

  return db.query.alerts.findMany({
    where: isNull(alerts.readBy),
    orderBy: [desc(alerts.createdAt)],
    limit: 50,
  });
}

export async function getUnreadAlertsCount() {
  const userId = await getUserId();

  const result = await db
    .select()
    .from(alerts)
    .where(isNull(alerts.readBy));

  return result.length;
}

export async function markAlertAsRead(alertId: string) {
  const userId = await getUserId();

  await db
    .update(alerts)
    .set({
      readBy: userId,
      readAt: new Date(),
    })
    .where(eq(alerts.id, alertId));

  revalidatePath("/");
}

export async function markAllAlertsAsRead() {
  const userId = await getUserId();

  await db
    .update(alerts)
    .set({
      readBy: userId,
      readAt: new Date(),
    })
    .where(isNull(alerts.readBy));

  revalidatePath("/");
}

export async function createAlert(
  type: string,
  severity: string,
  title: string,
  message: string,
  relatedId?: string
) {
  const userId = await getUserId();
  const role = await getUserRole(userId);

  if (role !== "admin") throw new Error("Only admins can create alerts");

  const { v4: uuidv4 } = await import("uuid");

  await db.insert(alerts).values({
    id: uuidv4(),
    type,
    severity,
    title,
    message,
    relatedId,
  });

  revalidatePath("/");
}
